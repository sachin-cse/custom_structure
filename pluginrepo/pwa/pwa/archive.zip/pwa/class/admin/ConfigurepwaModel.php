<?php defined('BASE') OR exit('No direct script access allowed.');
class ConfigurepwaModel extends Site
{
    function settings() {
		$ExtraQryStr = "name = 'PWA'";
		return $this->selectSingle(TBL_SETTINGS, "*", $ExtraQryStr);
	}
    
    function newSettings($params) {
        return $this->insertQuery(TBL_SETTINGS, $params);
    }
    
    function updateSetting($params) {
        $CLAUSE = "name = 'PWA'";
        return $this->updateQuery(TBL_SETTINGS, $params, $CLAUSE);
    }
}