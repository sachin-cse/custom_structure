<?php defined('BASE') OR exit('No direct script access allowed.');
class ConfigurepwaController extends REST
{
    private    $model;
    protected  $response = array();

    public function __construct($model) {
        parent::__construct();
        $this->model        = new $model;
    }

    function index() {

        $manifestFile   = ROOT_PATH.DIRECTORY_SEPARATOR.'manifest.json';
        $json           = file_get_contents($manifestFile);

        if($this->isJSON($json)) {

            $this->response['manifest']     = json_decode($json, true);
        }

        $settings                   = $this->model->settings();
        $this->response['resource'] = unserialize($settings['value']);

        return $this->response;
    }

    function addEditPwa() {
        
        $actMsg['type']     = 0;
        $actMsg['message']  = '';
        
        $status             = trim($this->_request['status']);

        $appName            = trim($this->_request['appName']);
        $shortName          = trim($this->_request['shortName']);
        $themeColor         = trim($this->_request['themeColor']);
        $backgroundColor    = trim($this->_request['backgroundColor']);
        $displayMode        = trim($this->_request['displayMode']);
        $orientation        = trim($this->_request['orientation']);
        $applicationScope   = trim($this->_request['applicationScope']);
        $startURL           = trim($this->_request['startURL']);

        if($appName != '' || $shortName != '' || $themeColor != '' || $backgroundColor != '' || $displayMode != '' || $orientation != '' || $applicationScope != '' || $startURL != '') {

            $manifestFile   = ROOT_PATH.DIRECTORY_SEPARATOR.'manifest.json';
            $swFile         = ROOT_PATH.DIRECTORY_SEPARATOR.'sw.js';
            $json           = file_get_contents($manifestFile);

            if($this->isJSON($json)) {

                $manifest   = json_decode($json, true);
            }
            
            $manifestArray['name']              = $appName;
            $manifestArray['short_name']        = $shortName;
            $manifestArray['theme_color']       = $themeColor;
            $manifestArray['background_color']  = $backgroundColor;
            $manifestArray['display']           = $displayMode;
            $manifestArray['orientation']       = $orientation;
            $manifestArray['Scope']             = $applicationScope;
            $manifestArray['start_url']         = $startURL;
            $manifestArray['icons']             = $manifest['icons'];

            $error = 0;
            if($_FILES['icons']['name'] && substr($_FILES['icons']['type'], 0, 5) == 'image') {

                $extension_lg_array = pathinfo($_FILES['icons']['name']);

                if(strtolower($extension_lg_array['extension'])=='png') {

                    list($w, $h) = getimagesize($_FILES['icons']['tmp_name']);
                    
                    if($w==512 && $h==512) {

                        $iconSizeArray = [72, 96, 128, 144, 152, 192, 384];
                        $fObj = new FileUpload;
                        
                        $targetLocation = MEDIA_FILES_ROOT.DIRECTORY_SEPARATOR.'icons'.DIRECTORY_SEPARATOR;
                        $fileName       = 'icon-512x512.png';

                        $upload = $fObj->moveUploadedFile($_FILES['icons'], $targetLocation.$fileName);
                        
                        $manifestArray['icons'] = [];

                        foreach($iconSizeArray as $iconSize) {

                            $iconName       = 'icon-'.$iconSize.'x'.$iconSize.'.png';

                            $ImageCreate = $fObj->createResizeForThumbnail($targetLocation.$fileName, $targetLocation, $iconName, $iconSize, $iconSize);

                            $manifestArray['icons'][] = array(
                                    'src'=>MEDIA_FILES_SRC.DIRECTORY_SEPARATOR.'icons'.DIRECTORY_SEPARATOR.$iconName,
                                    'sizes' =>$iconSize.'x'.$iconSize,
                                    'type' =>$_FILES['icons']['type']
                            );
                        }

                        $manifestArray['icons'][] = array(
                                'src'=>MEDIA_FILES_SRC.DIRECTORY_SEPARATOR.'icons'.DIRECTORY_SEPARATOR.$fileName,
                                'sizes' =>'512x512',
                                'type' =>$_FILES['icons']['type']
                        );
                    }
                    else {
                        $error = 1;
                        $actMsg['message'] = 'Icon file should be a 512x512 .png file.';
                    }
                }
                else {
                    $error = 1;
                    $actMsg['message'] = 'Icon file should be a 512x512 .png file.';
                }
            }
            
            if(!$error) {

                $manifestFile = fopen($manifestFile, "w");

                $manifestArray['splash_pages']  = null;

                fwrite($manifestFile, json_encode($manifestArray));
                fclose($manifestFile);

                $paramsPwa                      = array();
                $paramsPwa['status']            = $status;
                $paramsPwa['themeColor']        = $themeColor;

                if($this->_request['resource'][0]!='') {
                    
                    foreach($this->_request['resource'] as $resource) {

                        if($resource != '') {
                            $paramsPwa['resource'][] = $resource;
                        }
                    }
                    $swR = "'".implode("','" , $paramsPwa['resource'])."'";

                    $swFile = fopen($swFile, "w");
    
                    fwrite($swFile, 
    "const version = 'v1::static';
    
    self.addEventListener('install', e => {
        e.waitUntil(
            caches.open(version).then(cache => {
                return cache.addAll([
                    '".$startURL."',".$swR."
                ]).then(() => self.skipWaiting());
            })
        );
    });
    
    self.addEventListener(\"fetch\", function (event) {
        console.log('WORKER: fetch event in progress.');
    
        if (event.request.method !== 'GET') {
    
            return;
        }
        event.respondWith(
            caches
            .match(event.request)
            .then(function (cached) {
                var networked = fetch(event.request)
    
                    .then(fetchedFromNetwork, unableToResolve)
    
                    .catch(unableToResolve);
    
    
                return cached || networked;
    
                function fetchedFromNetwork(response) {
    
                    var cacheCopy = response.clone();
                    caches
                        .open(version + 'pages')
                        .then(function add(cache) {
                            cache.put(event.request, cacheCopy);
                        })
                        .then(function () {
                            console.log('WORKER: fetch response stored in cache.', event.request.url);
                        });
                    return response;
                }
    
                function unableToResolve() {
    
                    console.log('WORKER: fetch request failed in both cache and network.');
    
                    return new Response('<h1>Oops! Service unavailable. Please check your internet connection.</h1>', {
                        status: 503,
                        statusText: 'Service Unavailable',
                        headers: new Headers({
                            'Content-Type': 'text/html'
                        })
                    });
                }
            })
        );
    });
    self.addEventListener(\"activate\", function (event) {
        console.log('WORKER: activate event in progress.');
        event.waitUntil(
            caches
            .keys()
            .then(function (keys) {
                return Promise.all(
                    keys
                    .filter(function (key) {
    
                        return !key.startsWith(version);
                    })
                    .map(function (key) {
                        return caches.delete(key);
                    })
                );
            })
            .then(function () {
                console.log('WORKER: activate completed.');
            })
        );
    });"
                    );
                    fclose($swFile);
                }

                $params                         = [];
                $params['value']                = serialize($paramsPwa);

                $exist                          = $this->model->settings();

                if(!$exist) {

                    $params['name']             = 'PWA';
                    $this->model->newSettings($params);
                    $actMsg['message']          = 'Data inserted successfully.';
                } else {

                    $this->model->updateSetting($params);
                    $actMsg['message']          = 'Data updated successfully.';
                }

                $actMsg['type']     = 1;
            }
        }
        else
            $actMsg['message'] = 'All fields are mandatory!';

        
        return $actMsg;
    }
    
    function isJSON($string){
        return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
    }
}