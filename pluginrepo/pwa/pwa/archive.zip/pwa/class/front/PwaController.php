<?php defined('BASE') OR exit('No direct script access allowed.');
class PwaController extends REST
{
    private    $model;
    protected  $pageview;
    protected  $response = array();

    public function __construct($model) {
        parent::__construct();
        $this->model        = new $model;
    }

    function index($pageData = '') {

    }
}