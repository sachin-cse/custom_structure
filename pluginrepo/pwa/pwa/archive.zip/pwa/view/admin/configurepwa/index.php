<?php defined('BASE') OR exit('No direct script access allowed.');

if($data['manifest']) {
    $appName            = $data['manifest']['name'];
    $shortName          = $data['manifest']['short_name'];
    $themeColor         = $data['manifest']['theme_color'];
    $backgroundColor    = $data['manifest']['background_color'];
    $displayMode        = $data['manifest']['display'];
    $orientation        = $data['manifest']['orientation'];
    $applicationScope   = $data['manifest']['Scope'];
    $startURL           = $data['manifest']['start_url'];
}
if($data['resource']) {
    $status             = $data['resource']['status'];
}
?>
<div class="container-fluid">
    <?php
    if($data['act']['message'])
        echo ($data['act']['type'] == 1)? '<div class="alert alert-success">'.$data['act']['message'].'</div>':'<div class="alert alert-danger">'.$data['act']['message'].'</div>';
    ?>
    
    <div>
        <form name="modifycontent" action="" method="post" enctype="multipart/form-data">
            <div class="row">
                <div class="col-sm-8 contentL">
                    <div class="card">
                        <div class="card-body">
                            
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group m-b-20">
                                        <label>App Name</label>
                                        <input type="text" name="appName" value="<?php echo $appName;?>" class="form-control">
                                    </div>
                                </div>
                                
                                <div class="col-sm-6">
                                    <div class="form-group m-b-20">
                                        <label>Short Name</label>
                                        <input type="text" name="shortName" value="<?php echo $shortName;?>" maxlength="12" class="form-control">
                                    </div>
                                </div>
                                
                                <div class="col-sm-6">
                                    <div class="form-group m-b-20">
                                        <label>Theme Color</label>
                                        <input type="text" name="themeColor" value="<?php echo $themeColor;?>" maxlength="7" id="colorPicker1" class="form-control">
                                    </div>
                                </div>
                                
                                <div class="col-sm-6">
                                    <div class="form-group m-b-20">
                                        <label>Background Color</label>
                                        <input type="text" name="backgroundColor" value="<?php echo $backgroundColor;?>" maxlength="7" id="colorPicker2" class="form-control">
                                    </div>
                                </div>
                                
                                <div class="col-sm-6">
                                    <div class="form-group m-b-20">
                                        <label>Display Mode</label>
                                        <select name="displayMode" class="form-control">
                                            <option value="Browser" <?php echo ($displayMode == 'Browser') ? 'selected' : '';?>>Browser</option>
                                            <option value="Standalone" <?php echo ($displayMode == 'Standalone') ? 'selected' : '';?>>Standalone</option>
                                            <option value="Minimal UI" <?php echo ($displayMode == 'Minimal UI') ? 'selected' : '';?>>Minimal UI</option>
                                            <option value="Fullscreen" <?php echo ($displayMode == 'Fullscreen') ? 'selected' : '';?>>Fullscreen</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-sm-6">
                                    <div class="form-group m-b-20">
                                        <label>Orientation</label>
                                        <select name="orientation" class="form-control">
                                            <option value="Any" <?php echo ($orientation == 'Any') ? 'selected' : '';?>>Any</option>
                                            <option value="Portrait" <?php echo ($orientation == 'Portrait') ? 'selected' : '';?>>Portrait</option>
                                            <option value="Landscape" <?php echo ($orientation == 'Landscape') ? 'selected' : '';?>>Landscape</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-sm-6">
                                    <div class="form-group m-b-20">
                                        <label>Application Scope</label>
                                        <input type="text" name="applicationScope" value="<?php echo $applicationScope;?>" class="form-control">
                                    </div>
                                </div>
                                
                                <div class="col-sm-6">
                                    <div class="form-group m-b-20">
                                        <label>Start URL</label>
                                        <input type="text" name="startURL" value="<?php echo $startURL;?>" class="form-control">
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-title">
                            <h4>Resources for sw.js</h4>
                        </div>
                        <div class="card-body">
                            <div class="resourceList">
                                <span class="btn btn-default moreResource">Add</span>
                                <?php
                                if($data['resource']['resource']) {

                                    foreach($data['resource']['resource'] as $resource) {
                                        ?>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-sm-10">
                                                    <input type="text" name="resource[]" value="<?php echo $resource;?>" class="form-control">
                                                </div>
                                                <div class="col-sm-2 text-left p-l-0">
                                                    <span class="fa fa-times removeResource" title="Delete Resource"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                } else {
                                    ?>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-10">
                                                <input type="text" name="resource[]" value="" class="form-control">
                                            </div>
                                            <div class="col-sm-2 text-left p-l-0">
                                                <span class="fa fa-times removeResource" title="Delete Resource"></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-sm-4 contentS">
					<?php if(file_exists('../manifest.json') || file_exists('../sw.js')) {?>
						<div class="card">
							<div class="card-body">
								<div class="form-group">
									<?php
									if(file_exists('../manifest.json')) {
										echo '<i class="fa fa-caret-right m-r-10" style="color:#1976d2"></i> <a href="'.SITE_LOC_PATH.'/manifest.json" target="_blank">View manifest.json</a>';
									}
									
									if(file_exists('../sw.js')) {
										echo '<hr><i class="fa fa-caret-right m-r-10" style="color:#1976d2"></i> <a href="'.SITE_LOC_PATH.'/sw.js" target="_blank">View sw.js</a>';
									}
									?>
								</div>
							</div>
						</div>
					<?php }?>
					
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="1" <?php echo ($status == '1') ? 'selected' : '';?>>Enable</option>
                                    <option value="0" <?php echo ($status == '0') ? 'selected' : '';?>>Disable</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Upload Icon (Recommended Size: 512px * 512px)</label>
                                <input type="file" name="icons" class="form-control">
                                <?php
                                if(sizeof($data['manifest']['icons']) > 0) {
                                    
                                    echo '<hr>';
                                    
                                    foreach($data['manifest']['icons'] as $icon){
                                        echo '<div class="m-t-10">
                                            <div class="table_img"><img src="'.$icon['src'].'?t='.time().'" alt="'.$icon['sizes'].'"></div>
                                            <div class="m-t-5">'.$icon['sizes'].'</div>
                                        </div>';
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <input type="hidden" name="SourceForm" value="addEditPwa" />
                            <button type="submit" name="Save" value="Save" class="btn btn-info login_btn">Save</button>

                            <button type="button" name="Cancel" value="Close" onclick="location.href='<?php echo SITE_ADMIN_PATH;?>'" class="btn btn-default m-l-15">Close</button>   
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<link rel="stylesheet" type="text/css" href="<?php echo ADMIN_TMPL_PATH;?>/css/colorpicker.css" />
<script type="text/javascript" src="<?php echo ADMIN_TMPL_PATH;?>/js/lib/colorpicker.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#colorPicker1, #colorPicker2').ColorPicker({
            onSubmit: function(hsb, hex, rgb, el) {
                $(el).val('#' + hex);
                $(el).ColorPickerHide();
            },
            onBeforeShow: function () {
                $(this).ColorPickerSetColor(this.value);
            },
            onChange: function (hsb, hex, rgb, el) {
                $(el).val('#' + hex);
                /* this.find('.colorpicker_hex').children().val('#' + hex);
                console.log(this.find('.colorpicker_hex').children().val()); */
            },
            onShow: function (el) {
                $(el).fadeIn(500);
                return false;
            },
            onHide: function (el) {
                $(el).fadeOut(500);
                return false;
            },
        })
        .bind('keyup', function(){
            $(this).ColorPickerSetColor(this.value);
        });

        $('.resourceList').children('.form-group:last-child').find('.removeResource').remove();
        $(document).on('click', '.moreResource', function(){
            var more        = $(this),
                elem        = $(this).next('.form-group'),
                resourceRow = elem.html();
                
            if(more.parents('.resourceList').children('.form-group:last-child').find('.removeResource').length == false)
                more.parents('.resourceList').children('.form-group:last-child').find('.col-sm-2').append('<span class="fa fa-times removeResource" title="Delete Resource"></span>');

            more.parents('.resourceList').append('<div class="form-group">'+resourceRow+'</div>');
            more.parents('.resourceList').children('.form-group:last-child').find('input').val('');
            more.parents('.resourceList').children('.form-group:last-child').find('.removeResource').remove();

            
        });

        $(document).on('click', '.removeResource', function(){
            var more        = $(this);
            $(this).parents('.form-group').remove();
        });
    });
</script>