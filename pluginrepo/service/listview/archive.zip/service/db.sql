-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 23, 2019 at 09:59 AM
-- Server version: 5.7.24-log
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skeleton`
--

DELIMITER $$
--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `soundex_match`(needle varchar(128), haystack text, splitChar varchar(1)) RETURNS tinyint(4)
    DETERMINISTIC
begin
    declare spacePos int;
    declare searchLen int default length(haystack);
    declare curWord varchar(128) default '';
    declare tempStr text default haystack;
    declare tmp text default '';
    declare soundx1 varchar(64) default soundex(needle);
    declare soundx2 varchar(64) default '';
    
    set spacePos = locate(splitChar, tempStr);
    
    while searchLen > 0 do
      if spacePos = 0 then
        set tmp = tempStr;
        select soundex(tmp) into soundx2;
        if soundx1 = soundx2 then
          return 1;
        else
          return 0;
        end if;
      end if;
      
      if spacePos != 0 then
        set tmp = substr(tempStr, 1, spacePos-1);
        set soundx2 = soundex(tmp);
        if soundx1 = soundx2 then
          return 1;
        end if;
        set tempStr = substr(tempStr, spacePos+1);
        set searchLen = length(tempStr);
      end if;
      
      set spacePos = locate(splitChar, tempStr);

    end while;
    
    return 0;
    
  end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_service`
--

CREATE TABLE IF NOT EXISTS `tbl_service` (
  `id` int(11) NOT NULL,
  `menucategoryId` int(11) NOT NULL,
  `serviceName` varchar(200) NOT NULL,
  `serviceShortDescription` varchar(255) NOT NULL,
  `serviceDescription` longtext NOT NULL,
  `permalink` varchar(200) DEFAULT NULL,
  `serviceBanner` varchar(255) NOT NULL,
  `isBannerCaption` enum('1','0') NOT NULL DEFAULT '1',
  `serviceBannerCaption` text NOT NULL,
  `serviceImage` varchar(255) NOT NULL,
  `serviceIcon` varchar(255) NOT NULL,
  `serviceIcon1` varchar(255) NOT NULL,
  `serviceCatalog` varchar(255) NOT NULL,
  `serviceCatalogLink` varchar(255) NOT NULL,
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `isShowcase` enum('Y','N') NOT NULL DEFAULT 'Y',
  `displayOrder` int(11) NOT NULL DEFAULT '0',
  `entryDate` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_service`
--

INSERT INTO `tbl_service` (`id`, `menucategoryId`, `serviceName`, `serviceShortDescription`, `serviceDescription`, `permalink`, `serviceBanner`, `isBannerCaption`, `serviceBannerCaption`, `serviceImage`, `serviceIcon`, `serviceIcon1`, `serviceCatalog`, `serviceCatalogLink`, `status`, `isShowcase`, `displayOrder`, `entryDate`) VALUES
(1, 66, 'Design Service', 'Service one', '<p>Service one</p>', 'design-service', 'design-service-banner-1548055706.png', '1', 'Design Service', 'design-service-1547615184-0.jpg', '', '', '', '', 'Y', 'Y', 2, '2019-01-15 09:32:22'),
(2, 66, 'Printing Service', 'Screen printing service at best price. Screen printing service at best price.', '<p>Screen printing service at best price. Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.</p>\n<p>Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.</p>\n<p>Screen printing service at best price. Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.</p>\n<p>Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.</p>\n<ul><li>Screen printing service at best price. Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.</li>\n<li>\n<p>Screen printing service at best price. Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.</p>\n</li>\n<li>\n<p>Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.</p>\n</li>\n</ul><p>Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.Screen printing service at best price.</p>', 'printing-service', 'printing-service-banner.jpg', '1', 'Printing Service Banner', 'printing-service-1547615944-0.jpg', 'printing-service-icon.png', '', '', '', 'Y', 'Y', 1, '2019-01-15 10:22:11'),
(3, 66, 'Embroidery Service', 'Embroidery Service', '<p>Embroidery Service</p>', 'embroidery-service', '', '1', '', 'embroidery-service-1547615385-0.jpg', '', '', '', '', 'Y', 'Y', 3, '2019-01-16 10:30:50'),
(5, 66, 'Service with no image', 'Service with no image', '<p>Service with no image</p>', 'service-with-no-image', '', '1', '', '', '', '', '', '', 'Y', 'N', 4, '2019-01-16 19:03:53');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_service_gallery`
--

CREATE TABLE IF NOT EXISTS `tbl_service_gallery` (
  `id` int(11) NOT NULL,
  `serviceId` int(11) NOT NULL DEFAULT '0',
  `serviceImage` varchar(200) NOT NULL DEFAULT '',
  `status` enum('Y','N') NOT NULL DEFAULT 'Y',
  `displayOrder` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `tbl_service_gallery`
--

INSERT INTO `tbl_service_gallery` (`id`, `serviceId`, `serviceImage`, `status`, `displayOrder`) VALUES
(1, 1, 'design-service-1547615184-0.jpg', 'Y', 0),
(2, 2, 'printing-service-1547615250-0.jpg', 'Y', 0),
(3, 3, 'embroidery-service-1547615385-0.jpg', 'Y', 0),
(4, 2, 'printing-service-1547615944-0.jpg', 'Y', 0),
(5, 2, 'printing-service-1547700205-0.png', 'Y', 0),
(6, 2, 'printing-service-1547700205-1.jpg', 'Y', 0),
(7, 2, 'printing-service-1547700206-2.jpg', 'Y', 0),
(8, 2, 'printing-service-1547700206-3.jpg', 'Y', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_service`
--
ALTER TABLE `tbl_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_service_gallery`
--
ALTER TABLE `tbl_service_gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `photogalleryId` (`serviceId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_service`
--
ALTER TABLE `tbl_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_service_gallery`
--
ALTER TABLE `tbl_service_gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
