<?php 
defined('BASE') OR exit('No direct script access allowed');
$dbArr = array(
        "TBL_SERVICE" => "tbl_service",
        "TBL_SERVICE_GALLERY" => "tbl_service_gallery"
);