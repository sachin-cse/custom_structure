<?php defined('BASE') OR exit('No direct script access allowed');

if($data['serviceDetails']) {
	?>
	<div class="row">
		<?php if($data['itemNames']) {?>
			<aside class="col-md-3 col-sm-4 stickySidebar sk_service_side">
				<div class="sk_sideblock sk_sideblockShadow">
					<div class="subheading border_btm">Services</div>
					<?php echo $data['itemNames'];?>
				</div>
			</aside>
		<?php }?>

		<article class="<?php echo ($data['itemNames']) ? 'col-md-9 col-sm-8 stickyContent' : 'col-sm-12';?>">
            <?php
            $sk_icon = $withIcon = '';
            if(file_exists(MEDIA_FILES_ROOT.'/'.$data['pageData']['parent_dir'].'/thumb/'.$data['serviceDetails']['serviceIcon']) && $data['serviceDetails']['serviceIcon'] && $data['settings']['isIcon']){
                $sk_icon = '<figure class="sk_icon"><img class="lazy" src="'.STYLE_FILES_SRC.'/images/blank.png" data-src="'.MEDIA_FILES_SRC.'/'.$data['pageData']['parent_dir'].'/thumb/'.$data['serviceDetails']['serviceIcon'].'" alt="'.$data['serviceDetails']['serviceName'].'"></figure>';

                $withIcon = 'withIcon';
            }
            ?>
			<div class="sk_content_wrap <?php echo $withIcon;?>">
                <?php echo $sk_icon;?>
                
				<h1 class="heading"><?php echo $data['serviceDetails']['serviceName'];?></h1>
				<div class="sk_content">
					<?php 
                    if($data['settings']['isGallery']) {
                        if(sizeof($data['galleries']) > 1) {

                            echo '<div class="mb20" id="sk_gallery" style="display:none;">';

                                foreach($data['galleries'] as $gallery) {

                                    if(file_exists(MEDIA_FILES_ROOT.'/'.$data['pageData']['parent_dir'].'/thumb/'.$gallery['serviceImage']) && $gallery['serviceImage']){

                                        echo '<img alt="'.$data['serviceDetails']['serviceName'].'"
                                                    src="'.MEDIA_FILES_SRC.'/'.$data['pageData']['parent_dir'].'/thumb/'.$gallery['serviceImage'].'"
                                                    data-image="'.MEDIA_FILES_SRC.'/'.$data['pageData']['parent_dir'].'/normal/'.$gallery['serviceImage'].'"
                                                    data-description="'.$data['serviceDetails']['serviceName'].'">';
                                    }
                                }
                            echo '</div>';
                        }
                        else {
                            if(file_exists(MEDIA_FILES_ROOT.'/'.$data['pageData']['parent_dir'].'/large/'.$data['serviceDetails']['serviceImage']) && $data['serviceDetails']['serviceImage'])
                                echo '<figure class="sk_img_right"><img class="lazy" src="'.STYLE_FILES_SRC.'/images/blank.png" data-src="'.MEDIA_FILES_SRC.'/'.$data['pageData']['parent_dir'].'/large/'.$data['serviceDetails']['serviceImage'].'" alt="'.$data['serviceDetails']['serviceName'].'"></figure>';
                        }
                    }
					?>
					<div class="editor_text"><?php echo $data['serviceDetails']['serviceDescription'];?></div>
				</div>
				
                <?php if($data['settings']['isSocial'] && $data['settings']['socialSrc'] && $data['settings']['socialClass']) { ?>
                    <div class="sk_share mt30">
                        <script type="text/javascript" src="<?php echo $data['settings']['socialSrc'];?>"></script>
                        <div class="<?php echo $data['settings']['socialClass'];?>"></div>
                    </div>
                    <?php
                }
				if($data['serviceDetails']['serviceCatalogLink']) {
					echo '<div class="btn_left"><a href="'.$data['serviceDetails']['serviceCatalogLink'].'" target="_blank" class="btn btn_black">Download Catalog</a></div>';
				}
				?>
            </div>
            
            <?php
            if($data['settings']['isForm']) {

                echo '<section class="mt40">';
                    include 'form.php';
                echo '</section>';
            }
            ?>
		</div>
	</article>
	<?php

	if(sizeof($data['galleries']) > 1) {
		?>
		<script defer type="text/javascript">
            
            function $loadGallery(src){
            
                $(function () {
                    Modernizr.addTest("sk_gallery", $("#sk_gallery").length > 0);
                    Modernizr.load({
                        test: Modernizr.sk_gallery,
                        yep: src,
                        callback: function () {
                            $("#sk_gallery").unitegallery({
                                gallery_theme: "compact",
                                gallery_skin: "alexis",
                                theme_panel_position: "bottom",
                                theme_hide_panel_under_width: 599,
                                gallery_width: '100%',
                                gallery_height: 450,
                                gallery_preserve_ratio: true,
                                gallery_images_preload_type:"minimal",
                                gallery_autoplay: false,
                                gallery_pause_on_mouseover: true,

                                slider_scale_mode: "fill",
                                slider_controls_always_on: false,
                                slider_enable_bullets: false,
                                slider_enable_arrows: true,
                                slider_enable_fullscreen_button: true,
                                slider_enable_play_button: false,
                                slider_enable_progress_indicator: false,

                                slider_arrow_left_align_hor:"left",
                                slider_arrow_left_align_vert:"middle",
                                slider_arrow_left_offset_hor:10,
                                slider_arrow_left_offset_vert:0,
                                slider_arrow_right_align_hor:"right",
                                slider_arrow_right_align_vert:"middle",
                                slider_arrow_right_offset_hor:10,
                                slider_arrow_right_offset_vert:0,

                                strippanel_padding_top: 15,
                                strippanel_padding_bottom: 0,
                                strippanel_padding_left: 0,
                                strippanel_padding_right: 0,
                                thumb_width: 100,
                                thumb_height: 50,
                                strip_space_between_thumbs: 15,
                                thumb_border_effect: true,
                                thumb_border_width: 0,
                                thumb_border_color: "#d3d3d3",
                                thumb_over_border_width: 0,
                                thumb_over_border_color: "#d3d3d3",
                                thumb_selected_border_width: 1,
                                thumb_selected_border_color: "#0047b3",
                                thumb_round_corners_radius: 3,

                                thumb_color_overlay_effect: false,
                                thumb_overlay_color: "#ffffff",
                                thumb_overlay_opacity: 0.4,
                                thumb_overlay_reverse: false,

                                thumb_image_overlay_effect: false,
                                thumb_image_overlay_type: "bw",

                                /* hover controls*/

                                slider_fullscreen_button_align_hor: "right",
                                slider_fullscreen_button_align_vert: "bottom",
                                slider_fullscreen_button_offset_hor: 10,
                                slider_fullscreen_button_offset_vert: 10,

                                slider_enable_zoom_panel: true,
                                slider_zoompanel_skin: "",
                                slider_zoompanel_align_hor: "right",
                                slider_zoompanel_align_vert: "top",
                                slider_zoompanel_offset_hor: 6,
                                slider_zoompanel_offset_vert: 6,
                                //slider_enable_arrows: false,

                                slider_enable_text_panel: false,
                                slider_textpanel_always_on: false
                            });
                        }
                    });
                });
            }
            
            function waitForJquery(method, src, appendTo) {
                if (window.jQuery) {
                    method(src, appendTo);
                } else {
                    setTimeout(function () {
                        defer(method, src, appendTo);
                    }, 50);
                }
            }
            
            var src = "<?php echo STYLE_FILES_SRC;?>/js/ug-theme-compact.js";
            waitForJquery($loadGallery, src, 'body');
		</script>
		<?php
	}
}
?>