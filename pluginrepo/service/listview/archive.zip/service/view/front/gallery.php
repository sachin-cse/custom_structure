<?php defined('BASE') OR exit('No direct script access allowed');

if($data['pageContent']['displayHeading'] == 'Y') {
	$subHeading = ($data['pageContent']['subHeading']) ? '<span>'.$data['pageContent']['subHeading'].'</span>' : '';
	echo '<h1 class="heading text-center">'.$subHeading.$data['pageContent']['contentHeading'].'</h1>';
}

if($data['pageContent']['contentDescription'])
	echo '<div class="editor_text text-center mb30">'.$data['pageContent']['contentDescription'].'</div>';

if($data['services']) {
	?>
	<div class="owl-carousel gallery_list">
		<?php
		if($this->_request['dtaction'])
			echo '<div class="item"><a href="'.SITE_LOC_PATH.'/'.$this->_request['dtaction'].'/" class="galCat">Filter - All</a></div>';
		else
			echo '<div class="item"><a href="'.SITE_LOC_PATH.'/'.$this->_request['pageType'].'/" class="galCat selected">Filter - All</a></div>';
		
		foreach($data['services'] as $service) {
			if($this->_request['dtaction'])
				$link		= SITE_LOC_PATH.'/'.$service['permalink'].'/'.$this->_request['dtaction'].'/';
			else
				$link		= SITE_LOC_PATH.'/'.$service['permalink'].'/'.$this->_request['pageType'].'/';
			$selected 	= ($this->_request['pageType'] == $service['permalink']) ? 'selected' : '';
			echo '<div class="item"><a href="'.$link.'" class="galCat '.$selected.'">'.$service['serviceName'].'</a></div>';
		}
		?>
	</div>
</div>

<div class="gallery_inner">
	<?php
	if($data['galleries']) {
		echo '<ul class="ul row">';
			foreach($data['galleries'] as $gallery) {
				$this->loadView('service', 'gallery-list.php', $gallery);
			}
		echo '</ul>';
		if(isset($data['pageList'])) {
			echo '<div class="pagination">';
			echo '<p class="total">Page '.$data['page'].' of '.$data['totalPage'].'</p>';
			echo '<div>'.$data['pageList'].'</div>';
			echo '</div>';
		}
	}
	else
		echo '<div class="norecord">No record found!</div>';
	?>
</div>

<div class="container">
	<div class="btn_group btn_center">
		<a href="<?php echo SITE_LOC_PATH.'/about-us/';?>" class="btn btn_green">About Us</a>
		<a href="<?php echo SITE_LOC_PATH.'/services/';?>" class="btn">Our Services</a>
		<a href="<?php echo SITE_LOC_PATH.'/quotes/';?>" class="btn btn_black">Request Quote</a>
	</div>
	<?php
}
else
	echo '<div class="norecord">No record found!</div>';
?>