<?php 
defined('BASE') OR exit('No direct script access allowed.');
if($data['serviceImage'] && file_exists(MEDIA_FILES_ROOT.'/service/thumb/'.$data['serviceImage'])) {?>
	<li class="col-md-3 col-sm-4 col-xs-6">
		<div class="gallery_box">
			<a href="<?php echo MEDIA_FILES_SRC.'/service/large/'.$data['serviceImage'];?>"  data-lcl-thumb="<?php echo MEDIA_FILES_SRC.'/service/thumb/'.$data['serviceImage'];?>" class="galbox_link">
				<div class="gImg">
					<?php echo '<img src="'.MEDIA_FILES_SRC.'/service/thumb/'.$data['serviceImage'].'" alt="'.$data['serviceImage'].'">';?>
				</div>
				<div class="gText">
					<i class="fa fa-plus"></i>
				</div>
			</a>
		</div>
	</li>
<?php }?>