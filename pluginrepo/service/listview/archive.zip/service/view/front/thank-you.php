<?php defined('BASE') OR exit('No direct script access allowed');

if($data['msg'] && $data['msgShow']) {
	?>
    <div class="section">
		<div class="card" style="text-align: center;">
		    <div class="thankyou_txt">
		    	<h1 class="headingh2"><?php echo $data['msg'];?></h1>
		    </div>
		    <div class="thankyou_img">
		    	<img src="<?php echo $this->selfLoc.'media'.DS.'success.png';?>" alt="Thank You" title="Thank You" />
		    </div>
		</div>
	</div>
	<?php 
}
else
    Site::redirectToURL(SITE_LOC_PATH);
?>