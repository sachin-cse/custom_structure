<?php defined('BASE') OR exit('No direct script access allowed');?> 

<div class="form_wrap">
    <?php echo ($data['settings']['formHeading'])? '<h2 class="subheading">'.$data['settings']['formHeading'].'</h2>':'';?>
    <form name="quote" id="quote" method="POST">
        <ul class="row">
            <li class="col-sm-6">
                <label class="labelWrap">
                    <span>Name</span>
                    <input type="text" name="name">
                </label>
                <label class="labelWrap">
                    <span>Email Id</span>
                    <input type="text" name="email">
                </label>
                <label class="labelWrap">
                    <span>Phone No</span>
                    <input type="text" name="phone">
                </label>
            </li>
            <li class="col-sm-6">
                <label class="labelWrap">
                    <span>Message</span>
                    <textarea class="row3" name="message"></textarea>
                </label>
            </li>
            <li class="col-sm-6">
                <div class="labelWrap">
                    <?php echo ($data['settings']['isCaptcha'])? '<div class="captcha_img"><div data-sitekey="'.$data['settings']['googleSiteKey'].'" class="g-recaptcha"></div></div>' : '';?>
                    <div class="btn_wr">
                        <button type="submit" onclick="submitQuoteForm(this, event);">Submit</button>
                        <input type="hidden" name="SourceForm" value="Quote">
                        <input type="hidden" name="goto" value="<?php echo SITE_LOC_PATH.'/'.$data['pageData']['permalink'].'/thank-you/';?>" >
                        <input type="hidden" name="service" value="<?php echo $data['serviceDetails']['permalink'];?>">
                    </div>
                </div>
            </li>
        </ul>
        <div class="ErrInqMsg"></div>
    </form>
</div>

<script defer>
    function submitQuoteForm(obj, event) { 
        event.preventDefault();
        var btn      = $(obj), 
            form     = btn.parents('form'), 
            formData = form.serialize(),
            msg      = form.find('.ErrInqMsg'), 
            url      = "<?php echo SITE_LOC_PATH.'/ajx_action/'.$data['pageData']['permalink'];?>/";
        ajaxFormSubmit(form, formData, btn, msg, url, false);
    }
</script>