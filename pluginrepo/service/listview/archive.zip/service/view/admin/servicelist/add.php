<?php
defined('BASE') OR exit('No direct script access allowed.');

if($data['service']) {

    $IdToEdit                      = $data['service']['id'];
    $menucategoryId                = $data['service']['menucategoryId'];
    $menuPermalink                 = $data['service']['menuPermalink'];
    $serviceName                   = $data['service']['serviceName'];
    $permalink                     = $data['service']['permalink'];
    $serviceShortDescription       = $data['service']['serviceShortDescription'];
    $serviceDescription            = $data['service']['serviceDescription'];
    $serviceBanner                 = $data['service']['serviceBanner'];
    $isBannerCaption               = $data['service']['isBannerCaption'];
    $serviceBannerCaption          = $data['service']['serviceBannerCaption'];
    $serviceImage                  = $data['service']['serviceImage'];
    $serviceIcon                   = $data['service']['serviceIcon'];
    $serviceIcon1                  = $data['service']['serviceIcon1'];
    $serviceCatalogLink            = $data['service']['serviceCatalogLink'];
    $serviceCatalog                = $data['service']['serviceCatalog'];
    $displayOrder                  = $data['service']['displayOrder'];
    $status                        = $data['service']['status'];
    $isShowcase                    = $data['service']['isShowcase'];
	
	$qrystrPermalink			   = 'id != '.$IdToEdit;
}
else {

    $IdToEdit                      = $this->_request['id'];
    $menucategoryId                = $this->_request['menucategoryId'];
    $menuPermalink                 = $this->_request['menuPermalink'];
    $serviceName                   = $this->_request['serviceName'];
    $permalink                     = $this->_request['permalink'];
    $serviceShortDescription       = $this->_request['serviceShortDescription'];
    $serviceDescription            = $this->_request['serviceDescription'];
    $serviceBanner                 = $this->_request['serviceBanner'];
    $isBannerCaption               = $this->_request['isBannerCaption'];
    $serviceBannerCaption          = $this->_request['serviceBannerCaption'];
    $serviceImage                  = $this->_request['serviceImage'];
    $serviceIcon                   = $this->_request['serviceIcon'];
    $serviceIcon1                  = $this->_request['serviceIcon1'];
    $serviceCatalogLink            = $this->_request['serviceCatalogLink'];
    $serviceCatalog                = $this->_request['serviceCatalog'];
    $displayOrder                  = $this->_request['displayOrder'];
    $status                        = $this->_request['status'];
    $isShowcase                    = $this->_request['isShowcase'];
	
	$qrystrPermalink			   = 1;
}

?>
<div class="container-fluid">
    <?php
    if(isset($data['act']['message']))
        echo (isset($data['act']['type']) && $data['act']['type'] == 1)? '<div class="alert alert-success">'.$data['act']['message'].'</div>':'<div class="alert alert-danger">'.$data['act']['message'].'</div>';
    ?>
 
    <div>
        <form name="modifycontent" action="" method="post" enctype="multipart/form-data" id="form">
            <div class="row">
                <div class="col-sm-8 contentL">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Service Name *</label>
                                <input type="text" name="serviceName" value="<?php echo $serviceName;?>" class="form-control permalink copyToTitle" placeholder="" autocomplete="off" data-entity="<?php echo TBL_SERVICE;?>" data-qrystr="<?php echo $qrystrPermalink;?>" maxlength="255">
                            </div>
                            
                            <div class="form-group">
                                <label>Permalink</label>
                                <input type="text" name="permalink" value="<?php echo  $permalink;?>" class="form-control gen_permalink" placeholder="" autocomplete="off" maxlength="255">
                            </div>
                            
                            <div class="form-group">
                                <label>Short Description </label>
                                <div class="limitedtext">
                                    <textarea name="serviceShortDescription" class="form-control" maxlength="80"><?php echo $serviceShortDescription;?></textarea>
                                    <div class="charcount"></div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Description *</label>
                                <textarea name="serviceDescription" class="form-control editor"><?php echo $serviceDescription;?></textarea>
                            </div>
                        </div> 
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Upload Gallery Images (Recommended Size: <?php echo $data['settings']['imageWidth'].'px * '.$data['settings']['imageHeight'].'px';?>)</label>
                                <input type="file" name="serviceImage[]" multiple class="form-control" />
                                <?php
                                if($data['serviceImage']) {
                                    echo '<div class="gallery_wrap col3">';
                                    foreach($data['serviceImage'] as $sImage) {
                                        if($sImage['status'] == 'Y')
                                            $status  = '<span class="status"><i class="fa fa-check" title="Active"></i> Active</span>';
                                        else
                                            $status  = '<span class="status inactive"><i class="fa fa-times" title="Inactive"></i> Inactive</span>';

                                        if($sImage['serviceImage'] && file_exists(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$sImage['serviceImage'])) {
                                            ?>
                                            <div class="gal_list <?php echo ($serviceImage == $sImage['serviceImage']) ? 'checked' : '' ;?>" id="<?php echo 'recordsArray_'.$sImage['id']; ?>">
                                                <div class="gal_list_inner">
                                                    <div class="gal_img">
                                                        <?php echo '<img src="'.MEDIA_FILES_SRC.'/'.$this->_request['pageType'].'/thumb/'.$sImage['serviceImage'].'" alt="'.$sImage['serviceName'].'" />';?>
                                                    </div>
                                                    <div class="gal_action">
                                                        <label class="coverImage withradio float-left" data-serviceImage="<?php echo $sImage['serviceImage'];?>" data-editid="<?php echo $IdToEdit;?>" data-id="<?php echo $sImage['id'];?>" data-action="primary"><input type="radio" name="coverImage" <?php if($serviceImage == $sImage['serviceImage']) echo 'checked';?> value="<?php echo $sImage['id'];?>" > <span>Cover Image</span></label>
                                                        <?php if($serviceImage != $sImage['serviceImage']){ ?>
                                                            <label class="m-l-5 deleteGallery float-right">
                                                                <input type="radio" name="DeleteImg" value="<?php echo $sImage['id'];?>" onclick="deleteConfirm('warning','Are you sure to delete?');" > <span class="btn btn-sm btn-danger width-auto">Delete</span>
                                                            </label>
                                                        <?php }?>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                    }
                                    echo '</div>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
    
                </div>
                
                <div class="col-sm-4 contentS">
                    <?php if($IdToEdit){?>
                        <div class="card">
                            <div class="card-body">
                                <div class="form-group">
                                    <label class="m-b-0 w-100">
                                        <a style="line-height:36px;" href="<?php echo SITE_LOC_PATH.'/'.$permalink.'/'.$menuPermalink.'/';?>" target="_blank"><i class="fa fa-external-link"></i> Visit Page</a>

                                        <a href="index.php?pageType=<?php echo $this->_request['pageType'];?>&dtls=<?php echo $this->_request['dtls'];?>&dtaction=add&moduleId=<?php echo $this->_request['moduleId'];?>" class="btn btn-default pull-right">Add New</a>
                                    </label>
                                </div>
                            </div>
                        </div>
                    <?php }?>

                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="Y" <?php if($status=='Y') echo 'selected'?>>Active</option>
                                    <option value="N" <?php if($status=='N') echo 'selected'?>>Inactive</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>Display Priority</label>

                                <select name="displayOrder" class="form-control">
                                    <?php if($IdToEdit) {?>
                                    <option value="<?php echo $displayOrder;?>" >Stay as it is</option>
                                    <?php }?>
                                    <option value="T" <?php echo ($displayOrder == 'T')? 'selected':'';?>>Move to top</option>
                                    <option value="B" <?php echo ($displayOrder == 'B')? 'selected':'';?>>Move to bottom</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label><i class="fa fa-star"></i> Show on Showcase</label>
                                <select name="isShowcase" class="form-control">
                                    <option value="Y" <?php if($isShowcase=='Y') echo 'selected';?>>Yes</option>
                                    <option value="N" <?php if($isShowcase=='N') echo 'selected';?>>No</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Catalog Link</label>
                                <input type="text" name="serviceCatalogLink" value="<?php echo $serviceCatalogLink;?>" class="form-control" />
                            </div>
                            <div class="form-group m-t-20">
                                <div class="text-center">OR</div>
                                <label>Upload Catalog</label>
                                <input type="file" name="serviceCatalog" accept=".pdf" class="form-control" />
                                <?php
                                if($serviceCatalog && file_exists(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/catalog/'.$serviceCatalog)) {
                                    echo '<a href="'.MEDIA_FILES_SRC.'/'.$this->_request['pageType'].'/catalog/'.$serviceCatalog.'" target="_blank" class="dwnld float-left"><i class="fa fa-file-pdf-o"></i><br>click to view</a><div class="clearfix"></div>';
                                    ?>
                                    <label class="btn btn-sm btn-danger float-right m-t-10 deleteGallery">
                                        <input type="radio" name="DeleteFile" value="serviceCatalog" onclick="deleteConfirm('warning','Are you sure to delete?');" > <span>Delete Catalog</span>
                                    </label>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group clearfix">
                                <label>Upload Icon (Recommended Size: <?php echo $data['settings']['iconWidth'].'px * '.$data['settings']['iconHeight'].'px';?>)</label>
                                <input type="file" name="serviceIcon" class="form-control" />
                                <?php
                                if($serviceIcon && file_exists(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$serviceIcon)) {
                                    echo '<div class="table_img m-t-10"><img src="'.MEDIA_FILES_SRC.'/'.$this->_request['pageType'].'/thumb/'.$serviceIcon.'" alt="'.$serviceIcon.'"></div>';
                                    ?>
                                    <label class="btn btn-sm btn-danger float-right m-t-10 deleteGallery">
                                        <input type="radio" name="DeleteFile" value="serviceIcon" onclick="deleteConfirm('warning','Are you sure to delete?');" > <span>Delete Icon</span>
                                    </label>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
  
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Upload Banner Image (Recommended Size: <?php echo $data['settings']['bannerWidth'].'px * '.$data['settings']['bannerHeight'].'px';?>)</label>
                                <input type="file" name="serviceBanner" class="form-control" />
                                <?php
                                if($serviceBanner && file_exists(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$serviceBanner)) {
                                    echo '<div class="table_img m-t-10"><img src="'.MEDIA_FILES_SRC.'/'.$this->_request['pageType'].'/thumb/'.$serviceBanner.'" alt="'.$serviceBanner.'"></div>';
                                    ?>
                                    <label class="btn btn-sm btn-danger float-right m-t-10 deleteGallery">
                                        <input type="radio" name="DeleteFile" value="serviceBanner" onclick="deleteConfirm('warning','Are you sure to delete?');" > <span>Delete Banner</span>
                                    </label>
                                    <?php
                                }
                                ?>
                            </div>
                            <hr>
                            <div class="form-group">
                                <label>Banner Caption</label>
                                <label class="switch float-right">
                                    <input type="checkbox" name="isBannerCaption" <?php if($isBannerCaption == '1') echo 'checked';?>>
                                    <span></span>
                                </label>
                                <input type="text" name="serviceBannerCaption" value="<?php echo $serviceBannerCaption;?>" class="form-control" />
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Assign Under</label>
                                <select name="menucategoryId" class="form-control">
                                    <?php
                                    foreach($data['linkedPages'] as $linkedPage){
                                        echo '<option value="'.$linkedPage['categoryId'].'" '.(($menucategoryId == $linkedPage['categoryId']) ? 'selected' : '').'>'.$linkedPage['categoryName'].'</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <?php $this->loadView('seo/titlemeta', 'seopanel.php', $data['seoData']);?>
                </div>
            </div>
                
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <button type="button" name="Back" value="Back" onclick="history.back(-1);" class="btn btn-default m-r-15">Back</button>
                            
                            <input type="hidden" name="IdToEdit" value="<?php echo $IdToEdit;?>" />
                            <input type="hidden" name="SourceForm" value="addEditService" />
                            <button type="submit" name="Save" value="Save" class="btn btn-info login_btn">Save</button>

                            <button type="button" name="Cancel" value="Close" onclick="location.href='index.php?pageType=<?php echo $this->_request['pageType'];?>&dtls=<?php echo $this->_request['dtls'];?>&moduleId=<?php echo $this->_request['moduleId'];?>'" class="btn btn-default m-l-15">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript">
    function deleteConfirm(msgtype,title){
        swal({
            title: title,
            text: "",
            type: msgtype,
            showCancelButton: true,
            confirmButtonColor: "#ef5350",
            confirmButtonText: "Yes, delete it!!",
            closeOnConfirm: false
        },
        function(){
            $('#form').submit();
        });
    }
</script>