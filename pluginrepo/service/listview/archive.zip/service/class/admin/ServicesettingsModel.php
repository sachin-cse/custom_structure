<?php
defined('BASE') OR exit('No direct script access allowed.');
class ServicesettingsModel extends CommunicationsettingsModel
{
    
}