<?php
defined('BASE') OR exit('No direct script access allowed.');
class ServiceController extends REST
{
	private    $model;
	protected  $pageview;
	protected  $response = array();
	private    $settings = array();
	
    public function __construct($model) {
    	parent::__construct();
        $this->model        = new $model;
    }
    
	function index($pageData = []) {
        
        if($this->_request['dtls'])
            return;
		
        if($pageData) {
            
            $this->pageData     = $pageData;
            
            $settings           = $this->model->settings($pageData['parent_dir']);
            $settings           = unserialize($settings['value']);
            $settings['name']   = $pageData['parent_dir'];
            $this->settings     = $settings;
            
            if($this->_request['dtaction']) {
                
                if($this->_request['dtaction'] == 'thank-you')
                    $this->thankYou();
                else
                    $this->item();
            } else {
                $this->response['pageContent']  = $this->content($pageData['categoryId']);
                
                $records                        = $this->service();
                $itemList                       = $this->itemList($records);
                $this->response['itemList']     = implode($itemList);

                $this->pageview                 = 'index.php';
            }
            
            if($this->pageview) {

                $this->response['body']     = $this->pageview;
                $this->response['pageData'] = $pageData;
                return $this->response; 
            }
        }
    }
    
    function item() {
        
        $sd                                     = $this->model->serviceByPermalink($this->_request['pageType']);
        
        if($sd) {
            
            $records   	 	                    = $this->model->getServiceList(1);
            $recordSet                          = $this->itemNameList($records, 'ul bullet');
            $this->response['itemNames']        = implode($recordSet);
            
            $this->response['serviceDetails']   = $sd;
            $this->response['settings']   	 	= $this->settings;
            
            if($this->settings['isBanner']) {
                $banner     = $sd['serviceBanner'];

                if($banner && file_exists(MEDIA_FILES_ROOT.DS.$this->settings['name'].DS.'thumb'.DS.$banner)){
                    $this->response['innerBanner']['src']    = MEDIA_FILES_SRC.DS.$this->settings['name'].DS.'thumb'.DS.$banner;
                    $this->response['innerBanner']['alt']    = $sd['serviceName'];
                    $this->response['innerBanner']['caption']= ($sd['isBannerCaption'])? $sd['serviceBannerCaption']:'';
                }
            } elseif($this->settings['isBanner'] == 0) 
                $this->response['innerBanner']['src']    = '';

            if($this->settings['isGallery']) {
                $this->response['galleries']	= $this->model->getServiceGalleryByLimit("tsg.serviceId = ".$this->response['serviceDetails']['id'], 0, 12);
            }

            $this->pageview                     = 'service-details.php';
        }
    }
    
    function service() {
        
        $pageData = $this->pageData;
		
        $this->response['pageContent']      = $this->content($pageData['categoryId']);
        
        $ExtraQryStr                    	 = 1;
		$this->response['rowCount']			 = $this->model->serviceCount($ExtraQryStr);
		
		if($this->response['rowCount']) {
                
			$p                               = new Pager;
			$this->response['limit']         = ($this->settings['limit'])? $this->settings['limit'] : VALUE_PER_PAGE;
			$start                           = $p->findStart($this->response['limit'], $this->_request['page']);
			$pages                           = $p->findPages($this->response['rowCount'], $this->response['limit']);

			$records   	                     = $this->model->getServiceByLimit($ExtraQryStr, $start, $this->response['limit']);

			if(ceil($this->response['rowCount'] / $this->response['limit']) > 1) {
				$this->response['page']      = ($this->_request['page']) ? $this->_request['page'] : 1;
				$this->response['totalPage'] = ceil($this->response['rowCount'] / $this->response['limit']);

				$this->response['pageList']  = $p->pageList($this->response['page'], $_SERVER['REQUEST_URI'], $pages);
            }
            
            return $records;
		}
    }
    
    function content($categoryId) {
            
        $rsArry 				            = [];

        $rsArry['contentCount']	            = $this->model->countContentbymenucategoryId($categoryId);

        if($rsArry['contentCount']) {

            $p                              = new Pager;
            $rsArry['contentLimit']         = VALUE_PER_PAGE;
            $start                          = $p->findStart($rsArry['contentLimit'], $this->_request['contentPage']);
            $contentPages                   = $p->findPages($rsArry['contentCount'], $rsArry['contentLimit']);

            $rsArry['content']              = $this->model->getContentbymenucategoryId($categoryId, $start, $rsArry['contentLimit']);

            if($rsArry['contentCount'] > 0 && ceil($rsArry['contentCount'] / $rsArry['contentLimit']) > 1) {
                
                $rsArry['contentPage']      = ($this->_request['contentPage']) ? $this->_request['contentPage'] : 1;
                $rsArry['totalContentPage'] = ceil($rsArry['contentCount'] / $rsArry['contentLimit']);

                $rsArry['contentPageList']  = $p->pageList($rsArry['contentPage'], $_SERVER['REQUEST_URI'], $contentPages);
            }
    	    return $rsArry;
        }
    }
	    
    function ajx_action($pageData = []){

        if($this->_request['SourceForm'] == 'GalleryImage') {
            
            $actMsg['type']     	 = 0;
            
			if($this->_request['permalink']) {
				
				if($this->_request['permalink'] == 'all')
					$ExtraQryStr	 = 1;
				else
					$ExtraQryStr	 = "ts.permalink = '".addslashes($this->_request['permalink'])."'";
				
				$actMsg['gallery'] 	 = $this->model->getServiceGalleryByLimit($ExtraQryStr, 0, 12);
				
				$actMsg['type']		 = 1;
				$actMsg['message']   = 'Please Wait...';
			}
			else
                $actMsg['message'] = 'Something went wrong!';
            
            return $actMsg;
		}
        
        elseif($this->_request['SourceForm'] == 'Quote') {
            
            $actMsg['type']     = 0;
            
			if($this->_request['name'] && $this->_request['email'] && $this->_request['phone'] && $this->_request['message']) {
                
                $settings         = $this->model->settings($pageData['parent_dir']);
                $settings         = unserialize($settings['value']);
                
				$gObj = new genl();
				if($gObj->validate_email($this->_request['email'])) {
                    
                    $error = 0;
                    
                    if($settings['isCaptcha'] == '1') {
                    
                    
                        if($this->_request['g-recaptcha-response']) {

                            $google_url		= "https://www.google.com/recaptcha/api/siteverify";
                            $secret			= $settings['googleSecretKey'];
                            $ip				= $_SERVER['REMOTE_ADDR'];

                            $ch = curl_init();
                            curl_setopt_array($ch, [
                                CURLOPT_URL => $google_url,
                                CURLOPT_POST => true,
                                CURLOPT_POSTFIELDS => [
                                    'secret' => $secret,
                                    'response' => $this->_request['g-recaptcha-response'],
                                    'remoteip' => $_SERVER['REMOTE_ADDR']
                                ],
                                CURLOPT_RETURNTRANSFER => true
                            ]);
                            $output = curl_exec($ch);
                            curl_close($ch);

                            $responseData = json_decode($output);

                            /*$url			= file_get_contents($google_url."?secret=".$secret."&response=".$this->_request['g-recaptcha-response']."&remoteip=".$ip);

                            $responseData 	= json_decode($url);*/

                            if(!$responseData->success) {
                                $error = 1;
                                $actMsg['message'] = 'Captcha verification failed!';
                            }
                        } else {
                            $error = 1;
							$actMsg['message'] = 'Please verify that you are not a robot!';
                        }
					}
                    
                    if(!$error) {
                       
                        $msg_details['emailBody']       = $settings['emailBody'];
                        $msg_details['emailSubject']    = $settings['emailSubject'];

                        $service 	 		 		    = $this->model->serviceByPermalink($this->_request['service']);
							
                        $paramsSerialize			    = array();
                        $paramsSerialize['type']	    = 'Service';
                        $paramsSerialize['id']		    = $service['id'];
                        $paramsSerialize['name']	    = $service['serviceName'];

                        $params                         = array();
                        $params['name']                 = $this->_request['name'];
                        $params['email']                = $this->_request['email'];
                        $params['phone']                = $this->_request['phone'];
                        $params['subject']              = $msg_details['emailSubject'];
                        $params['comments'] 		    = $this->_request['message'];
                        $params['contactType']  	    = 'Q';
                        $params['status']  			    = 'Y';
                        $params['serializedData']	    = serialize($paramsSerialize);
                        $params['entryDate']            = date('Y-m-d H:i:s');

                        $insId   = $this->model->newContact($params);

                        if($insId) {

                            /********************* Send Email *******************/
                            $to         = $settings['toEmail'];
                            $from       = "From: ".SITE_NAME."<".$settings['replyTo'].">";

                            $opt['cc']  = $settings['cc'];
                            $opt['bcc'] = $settings['bcc'];

                            $subject    = $msg_details['emailSubject'];
                            $msg        = $msg_details['emailBody'];

                            $name		= $this->_request['name'];
                            $email		= $this->_request['email'];
                            $phone		= $this->_request['phone'];
                            $message	= $this->_request['message'];
                            $service	= $service['serviceName'];
                            $arr = array(
                                    "{siteName}"		=> SITE_NAME,
                                    "{name}" 			=> $name,
                                    "{email}" 			=> $email,
                                    "{phone}" 			=> $phone,
                                    "{service}"         => $service,
                                    "{comments}"        => $message,
                                    "{link}" 			=> SITE_ADMIN_PATH
                            );

                            $msg    = strtr($msg,$arr);
                            $mail   = sendEmail($to, $from, $subject, $msg, $opt);
                            /********************* Send Email *******************/
                            
                            if($mail == 1) {

                                $this->session->write('MSGSHOW', 'Y');
                                $this->session->write('MSG', $settings['successMsg']);

                                $actMsg['type']           = 1;
                                $actMsg['message']        = 'Please wait...';
                                $actMsg['goto']           = $this->_request['goto'];
                            }
                            else
                                $actMsg['message']  = $mail;
                        }
                        else
                            $actMsg['message']  = 'Oops! Something went wrong. Please close your browser window and try again.';
                    }	
				}
				else
					$actMsg['message'] = 'Email ID is invalid!';
			}
			else
                $actMsg['message'] = 'All fields are mandatory!';
            
            return $actMsg;
		}
    }
    
    function thankYou(){
    	$this->response['msgShow'] 			= ($this->session->read('MSGSHOW')) ? $this->session->read('MSGSHOW') : '';
    	$this->response['msg'] 			    = ($this->session->read('MSG')) ? $this->session->read('MSG') : '';
		
    	$this->pageview 			        = 'thank-you.php';
        
        $this->session->write('MSGSHOW', '');
        $this->session->write('MSG', '');
    }
    
    function showcase($opt = []) {
        
        $settings           = $this->model->settings($opt['module']);
        $settings           = unserialize($settings['value']);
        $settings['name']   = $opt['module'];
        $this->settings     = $settings;
        
        if($settings['isShowcase']) {
        
            $showcaseFile           = CACHE_ROOT.DS.'service_showcase.html';
            if(file_exists($showcaseFile)) {
                include $showcaseFile;
                return;
            }

            $limit      = ($settings['showcaseNo'])? $settings['showcaseNo'] : 3;
            $records	= $this->model->getServiceByLimit("ts.isShowcase = 'Y'", 0, $limit);

            if($records) {

                $wrapcss    = ($opt['wrapcss']) ?   $opt['wrapcss'] : '';
                $css        = ($opt['css']) ?       $opt['css']     : '';
                $col        = ($opt['col'])?        $opt['col']     : 'col-sm-4 col-xs-6';
                $slider     = ($opt['slider'])?     $opt['slider']  : false;
                $withIcon   = ($settings['isIcon'])?'withIcon'      : '';

                $this->result[]   = '<section class="section '.$wrapcss.'">
                                        <div class="container">
                                            <h2 class="heading">'.headingModify($settings['showcaseTitle']).'</h2>';

                if(trim($settings['showcaseDescription'])) {
                    $this->result[]   = '<div class="sk_content_wrap mb30">
                                        <div class="sk_content">
                                            <div class="editor_text">
                                                '.$settings['showcaseDescription'].'
                                            </div>
                                        </div>
                                    </div>';
                }

                $this->result[]   = '<div class="'.$css.'">';
                
                $this->itemList($records, $col, $slider);
                
                $this->result[] = '</div></div></section>';

                $html = implode($this->result);

                echo $html;
            }
        }
    }
    
    function itemList($records, $col = 'col-sm-4 col-xs-6', $slider = false) {
        
        $withIcon   = ($this->settings['isIcon'])? 'withIcon' : '';
        
        if($slider === true){
            $this->result[]     = '<div class="owl-carousel">';
            $itemElem           = '<div class="item">'; 
            $itemElemEnd        = '</div>'; 
            $itemElemWrapEnd    = '</div><script defer="" type="text/javascript">
                                        function loadOwl(){
                                        if(window.jQuery){
                                            $(".service_list .owl-carousel").owlCarousel({ 
                                                items: 3,
                                                loop: false,
                                                autoplay: false,
                                                autoplayHoverPause: true,
                                                autoplayTimeout: 3000,
                                                smartSpeed: 1000,
                                                margin: 30,
                                                dots: false,
                                                nav: true,
                                                navElement: \'div\',
                                                navText: ["<i class=\'fa fa-angle-left\'></i>", "<i class=\'fa fa-angle-right\'></i>"],
                                                lazyLoad: true,
                                                responsive: {
                                                    0: { items: 1 },
                                                    480: { items: 1 },
                                                    600: { items: 2 },
                                                    768: { items: 2 },
                                                    992: { items: 3 },
                                                    1600: { items: 3 }
                                                }, 
                                            });} else {setTimeout(function(){ loadOwl();}, 50);}}loadOwl();</script>'; 
            $lazyClass          = 'owl-lazy';
        } else {
            $this->result[]     = '<ul class="ul row">';
            $itemElem           = '<li class="'.$col.'">';
            $itemElemEnd        = '</li>'; 
            $itemElemWrapEnd    = '</ul>'; 
            $lazyClass          = 'lazy';
        }
        
        foreach($records as $data) {
            
            $link = SITE_LOC_PATH.'/'.$data['permalink'].'/'.$data['menuPermalink'].'/';

            $figureImg = $figureIcon = '';

            if( $this->settings['isGallery'] ) {

                if( $data['serviceImage'] && file_exists(MEDIA_FILES_ROOT.DS.$this->settings['name'].DS.'thumb'.DS.$data['serviceImage']) )
                    $figSrc = MEDIA_FILES_SRC.'/'.$this->settings['name'].'/thumb/'.$data['serviceImage'];
                else
                    $figSrc = STYLE_FILES_SRC.'/images/noimage.png';

                $figureImg = '<figure class="sk_img">
                            <img class="'.$lazyClass.'" src="'.STYLE_FILES_SRC.'/images/blank.png" data-src="'.$figSrc.'" alt="'.$data['serviceName'].'">
                        </figure>';
            }

            if( $this->settings['isIcon'] && $data['serviceIcon'] && file_exists(MEDIA_FILES_ROOT.DS.$this->settings['name'].DS.'thumb'.DS.$data['serviceIcon']) ) {

                $figureIcon = '<figure class="sk_icon">
                        <img class="'.$lazyClass.'" src="'.STYLE_FILES_SRC.'/images/blank.png" data-src="'.MEDIA_FILES_SRC.'/'.$this->settings['name'].'/thumb/'.$data['serviceIcon'].'" alt="'.$data['serviceName'].'">
                    </figure>';
            }
            
            if($this->settings['isShortDesc'])
                $shortDescription = ($data['serviceShortDescription'])? '<div class="sk_para">'.$data['serviceShortDescription'].'</div>' : '<div class="sk_para">'.substr(strip_tags($data['serviceDescription']), 0, 80).'...</div>';
            else
                $shortDescription = '';
            
            $btn = ($this->settings['isButton'])? '<span class="readmore"><i class="fa fa-angle-right"></i> '.$this->settings['btnText'].'</span>' : '';

            $this->result[] = sprintf('%s
                        <div class="sk_box %s">
                            <a href="%s">%s<div class="sk_text">
                                    %s
                                    <h2 class="subheading">%s</h2>
                                    %s
                                    %s
                                </div>
                            </a>
                        </div>
                    %s', $itemElem, $withIcon, $link, $figureImg, $figureIcon, $data['serviceName'], $shortDescription, $btn, $itemElemEnd);
        }
        
        $this->result[]   = $itemElemWrapEnd;

        return $this->result;
    }
    
    function itemNames($opt = []) {
        $records	= $this->model->getServiceByLimit(1, 0, 10);
        $this->itemNameList($records, $opt['css']);
        $html = implode($this->result);

        echo $html;
    }

    function itemNameList($records, $css = '') {
        
        $css = ($css)? 'class="'.$css.'"' : '';

        $this->result[]   = '<ul '.$css.'>';
        foreach($records as $cData){
            $active   = ($cData['permalink'] == $this->_request['pageType']) ? 'class="active"' : '';
            $this->result[] = '<li '.$active.'><a href="'.SITE_LOC_PATH.'/'.$cData['permalink'].'/'.$cData['menuPermalink'].'/'.'" >'.$cData['serviceName'].'</a> </li>';
        }
        $this->result[]   = '</ul>';
        return $this->result;
    }
}
?>