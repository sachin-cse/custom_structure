<?php
defined('BASE') OR exit('No direct script access allowed.');
class ServiceModel extends ContentModel
{
	function serviceById($id) {
		$ENTITY      = TBL_SERVICE." ts LEFT JOIN ".TBL_MENU_CATEGORY." tmc ON (ts.menucategoryId = tmc.categoryId)";
		$ExtraQryStr = "ts.id = ".addslashes($id);
		return $this->selectSingle($ENTITY, "ts.*", $ExtraQryStr);
	}
	
    function serviceByPermalink($permalink) {
		$ENTITY      = TBL_SERVICE." ts LEFT JOIN ".TBL_MENU_CATEGORY." tmc ON (ts.menucategoryId = tmc.categoryId)";
		$ExtraQryStr = "ts.permalink = '".addslashes($permalink)."'";
		return $this->selectSingle($ENTITY, "ts.*", $ExtraQryStr);
	}
    
    function serviceCount($ExtraQryStr) {
		$ENTITY      = TBL_SERVICE." ts LEFT JOIN ".TBL_MENU_CATEGORY." tmc ON (ts.menucategoryId = tmc.categoryId)";
		$ExtraQryStr .= " AND ts.status = 'Y'";
        return $this->rowCount($ENTITY, "ts.id", $ExtraQryStr);
	}
    
    function getServiceByLimit($ExtraQryStr, $start, $limit) {
		$ENTITY      = TBL_SERVICE." ts LEFT JOIN ".TBL_MENU_CATEGORY." tmc ON (ts.menucategoryId = tmc.categoryId)";
		$ExtraQryStr .= " AND ts.status = 'Y' ORDER BY ts.displayOrder";
		return $this->selectMulti($ENTITY, "ts.*, tmc.categoryName menuName, tmc.permalink menuPermalink", $ExtraQryStr, $start, $limit);
	}
    
    function getServiceList($ExtraQryStr) {
		$ENTITY      = TBL_SERVICE." ts LEFT JOIN ".TBL_MENU_CATEGORY." tmc ON (ts.menucategoryId = tmc.categoryId)";
		$ExtraQryStr .= " AND ts.status = 'Y' ORDER BY ts.displayOrder";
		return $this->selectAll($ENTITY, "ts.serviceName, ts.permalink, tmc.categoryName menuName, tmc.permalink menuPermalink", $ExtraQryStr);
	}
	
	/* ----------------------------------------- TBL_SERVICE_GALLERY ----------------------------------------- */
	function serviceGalleryCount($ExtraQryStr) {
		$ENTITY		  = TBL_SERVICE_GALLERY." tsg JOIN ".TBL_SERVICE." ts ON (tsg.serviceId = ts.id)";
		$ExtraQryStr .= " AND tsg.status = 'Y'";
        return $this->rowCount($ENTITY, "tsg.id", $ExtraQryStr);
	}
	
	function getServiceGalleryByLimit($ExtraQryStr, $start, $limit) {
		$ENTITY		  = TBL_SERVICE_GALLERY." tsg JOIN ".TBL_SERVICE." ts ON (tsg.serviceId = ts.id)";
		$ExtraQryStr .= " AND tsg.status = 'Y' ORDER BY tsg.displayOrder";
		return $this->selectMulti($ENTITY, "tsg.*", $ExtraQryStr, $start, $limit); 	
	}
	
	/* ----------------------------------------- TBL_SETTINGS ------------------------------------------------ */
	function settings($name) {
        $ExtraQryStr = "name = '".addslashes($name)."'";
		$settings = $this->selectSingle(TBL_SETTINGS, "value", $ExtraQryStr);
        
        if(!$settings){
            $ExtraQryStr = "name = 'communication'";
            $settings = $this->selectSingle(TBL_SETTINGS, "value", $ExtraQryStr);
        }
        
        return $settings;
    }
    
    function newContact($params){
        return $this->insertQuery(TBL_CONTACT, $params);
	}
}
?>