<?php
defined('BASE') OR exit('No direct script access allowed');

include('content.php');


if($data['itemList']) {
	?>
	<div class="brand_list">
        <?php echo $data['itemList']; ?>
	</div>
	<?php
	if(isset($data['pageList'])) {
		echo '<div class="pagination">';
		echo '<p class="total">Page '.$data['page'].' of '.$data['totalPage'].'</p>';
		echo '<div>'.$data['pageList'].'</div>';
		echo '</div>';
	}	
}
else
	echo '<div class="norecord">No record found!</div>';
?>