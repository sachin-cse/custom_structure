<?php
defined('BASE') OR exit('No direct script access allowed.');

if($data['client']) {

    $IdToEdit                       = $data['client']['clientId'];
    $clientName                     = $data['client']['clientName'];
    $permalink                      = $data['client']['permalink'];
    $url                            = $data['client']['url'];
    $urlTarget                      = $data['client']['urlTarget'];
    $clientDescription              = $data['client']['clientDescription'];
    $clientImage                    = $data['client']['clientImage'];
    $displayOrder                   = $data['client']['displayOrder'];
    $status                         = $data['client']['status'];
    $isShowcase                     = $data['client']['isShowcase'];
	
	$qrystrPermalink			    = 'clientId != '.$IdToEdit;
}
else {

    $IdToEdit                       = $this->_request['clientId'];
    $clientName                     = $this->_request['clientName'];
    $permalink                      = $this->_request['permalink'];
    $url                            = $this->_request['url'];
    $urlTarget                      = $this->_request['urlTarget'];
    $clientDescription              = $this->_request['clientDescription'];
    $clientImage                    = $this->_request['clientImage'];
    $displayOrder                   = $this->_request['displayOrder'];
    $status                         = $this->_request['status'];
    $isShowcase                     = $this->_request['isShowcase'];
	
	$qrystrPermalink			    = 1;
}

?>
<div class="container-fluid">
    <?php
    if(isset($data['act']['message']))
        echo (isset($data['act']['type']) && $data['act']['type'] == 1)? '<div class="alert alert-success">'.$data['act']['message'].'</div>':'<div class="alert alert-danger">'.$data['act']['message'].'</div>';
    ?>
 
    <div>
        <form name="modifycontent" action="" method="post" enctype="multipart/form-data" id="form">
            <div class="row">
                <div class="col-sm-8 contentL">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Client Name *</label>
                                <input type="text" name="clientName" value="<?php echo $clientName;?>" class="form-control permalink copyToTitle" placeholder="" autocomplete="off" data-entity="<?php echo TBL_CLIENT;?>" data-qrystr="<?php echo $qrystrPermalink;?>" maxlength="255">
                            </div>
                            
                            <div class="form-group">
                                <label>Permalink</label>
                                <input type="text" name="permalink" value="<?php echo  $permalink;?>" class="form-control gen_permalink" placeholder="" autocomplete="off" maxlength="255">
                            </div>
                            
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <div class="form-group">
                                            <label>Website (Url should start with https:// or http://)</label>
                                            <input type="text" name="url" value="<?php echo $url;?>" class="form-control" placeholder="">
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>Target </label>
                                            <select name="urlTarget" class="form-control">
                                                <option value="_blank" <?php if($urlTarget=='_blank') echo 'selected'?>>Open in new tab (_blank)</option>
                                                <option value="_self" <?php if($urlTarget=='_self') echo 'selected'?>>Open in same tab (_self)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="clientDescription" class="form-control editor"><?php echo $clientDescription;?></textarea>
                            </div>
                        </div> 
                    </div>
    
                </div>
                
                <div class="col-sm-4 contentS">
                    <?php if($IdToEdit){?>
                        <div class="card">
                            <div class="card-body">
                                <div class="form-group">
                                    <label class="m-b-0 w-100">
                                        <a href="index.php?pageType=<?php echo $this->_request['pageType'];?>&dtls=<?php echo $this->_request['dtls'];?>&dtaction=add&moduleId=<?php echo $this->_request['moduleId'];?>" class="btn btn-default pull-right">Add New</a>
                                    </label>
                                </div>
                            </div>
                        </div>
                    <?php }?>

                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="Y" <?php if($status=='Y') echo 'selected'?>>Active</option>
                                    <option value="N" <?php if($status=='N') echo 'selected'?>>Inactive</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>Display Priority</label>

                                <select name="displayOrder" class="form-control">
                                    <?php if($IdToEdit) {?>
                                    <option value="<?php echo $displayOrder;?>" >Stay as it is</option>
                                    <?php }?>
                                    <option value="T" <?php echo ($displayOrder == 'T')? 'selected':'';?>>Move to top</option>
                                    <option value="B" <?php echo ($displayOrder == 'B')? 'selected':'';?>>Move to bottom</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label><i class="fa fa-star"></i> Show on Showcase</label>
                                <select name="isShowcase" class="form-control">
                                    <option value="Y" <?php if($isShowcase=='Y') echo 'selected';?>>Yes</option>
                                    <option value="N" <?php if($isShowcase=='N') echo 'selected';?>>No</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group clearfix">
                                <label>Upload Image (Recommended Size: <?php echo $data['settings']['imageWidth'].'px * '.$data['settings']['imageHeight'].'px';?>)</label>
                                <input type="file" name="clientImage" class="form-control" />
                                <?php
                                if($clientImage && file_exists(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$clientImage)) {
                                    echo '<div class="table_img m-t-10"><img src="'.MEDIA_FILES_SRC.'/'.$this->_request['pageType'].'/thumb/'.$clientImage.'" alt="'.$clientImage.'"></div>';
                                    ?>
                                    <label class="btn btn-sm btn-danger float-right m-t-10 deleteGallery">
                                        <input type="radio" name="DeleteFile" value="clientImage" onclick="deleteConfirm('warning','Are you sure to delete?');" > <span>Delete Image</span>
                                    </label>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <button type="button" name="Back" value="Back" onclick="history.back(-1);" class="btn btn-default m-r-15">Back</button>
                            
                            <input type="hidden" name="IdToEdit" value="<?php echo $IdToEdit;?>" />
                            <input type="hidden" name="SourceForm" value="addEditClient" />
                            <button type="submit" name="Save" value="Save" class="btn btn-info login_btn">Save</button>

                            <button type="button" name="Cancel" value="Close" onclick="location.href='index.php?pageType=<?php echo $this->_request['pageType'];?>&dtls=<?php echo $this->_request['dtls'];?>&moduleId=<?php echo $this->_request['moduleId'];?>'" class="btn btn-default m-l-15">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript">
    function deleteConfirm(msgtype,title){
        swal({
            title: title,
            text: "",
            type: msgtype,
            showCancelButton: true,
            confirmButtonColor: "#ef5350",
            confirmButtonText: "Yes, delete it!!",
            closeOnConfirm: false
        },
        function(){
            $('#form').submit();
        });
    }
</script>