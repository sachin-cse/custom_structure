<?php defined('BASE') OR exit('No direct script access allowed.');
class ClientlistController extends REST
{
    private    $model;
	protected  $response = array();
	
    public function __construct($model) {
    	parent::__construct();
        $this->model        = new $model;
    }
    
	function index($act = []) {
            
        $this->response['linkedPages']          = $this->model->getLinkedPages($this->_request['pageType'], 0, 100);
            
        $settings                               = $this->model->settings($this->_request['pageType']);
        $this->response['settings']             = unserialize($settings['value']);
        
        if(isset($this->_request['editid']) || isset($act['editid']) || $this->_request['dtaction'] == 'add') {
            
            $editid = ($this->_request['editid'])? $this->_request['editid']:$act['editid'];
            
            if($editid) {
                $this->response['client']      = $this->model->clientById($editid);

                $titleandMetaUrl               = '/'.$this->response['client']['permalink'].'/'.$this->response['client']['menuPermalink'].'/';
                $seoModel                      = new TitlemetaModel;
                $this->response['seoData']     = $seoModel->titleMetaByUrl($titleandMetaUrl);
            }
        }
        else {
        
            $ExtraQryStr = 1;

            // SEARCH START --------------------------------------------------------------
            if(isset($this->_request['searchText']))
                $this->session->write('searchText', $this->_request['searchText']);

            if($this->session->read('searchText'))
                $ExtraQryStr        .= " AND clientName LIKE '%".addslashes($this->session->read('searchText'))."%'";

            if(isset($this->_request['searchStatus']))
                $this->session->write('searchStatus', $this->_request['searchStatus']);

            if($this->session->read('searchStatus'))
                $ExtraQryStr        .= " AND status = '".addslashes($this->session->read('searchStatus'))."'";

            if(isset($this->_request['searchShowcase']))
                $this->session->write('searchShowcase', $this->_request['searchShowcase']);

            if($this->session->read('searchShowcase'))
                $ExtraQryStr        .= " AND isShowcase = '".addslashes($this->session->read('searchShowcase'))."'";

            if(isset($this->_request['Reset']) || isset($this->_request['Search'])) {

                if(isset($this->_request['Reset'])){

                    $this->session->write('searchText',     '');
                    $this->session->write('searchStatus',   '');
                    $this->session->write('searchShowcase', '');
                }

                $this->model->redirectToUrl(SITE_ADMIN_PATH.'/index.php?pageType='.$this->_request['pageType'].'&dtls='.$this->_request['dtls'].'&moduleId='.$this->_request['moduleId']);
            }
            // SEARCH END ----------------------------------------------------------------

            $this->response['rowCount']     = $this->model->clientCount($ExtraQryStr);

            if($this->response['rowCount']) {

                $p                          = new Pager;
                $this->response['limit']    = VALUE_PER_PAGE;
                $start                      = $p->findStart($this->response['limit'], $this->_request['page']);
                $pages                      = $p->findPages($this->response['rowCount'], $this->response['limit']);

                $this->response['clients']    	 = $this->model->getClientByLimit($ExtraQryStr, $start, $this->response['limit']);

                if($this->response['rowCount'] > 0 && ceil($this->response['rowCount'] / $this->response['limit']) > 1) {
                    $this->response['page']      = ($this->_request['page']) ? $this->_request['page'] : 1;
                    $this->response['totalPage'] = ceil($this->response['rowCount'] / $this->response['limit']);

                    $this->response['pageList']  = $p->pageList($this->response['page'], $_SERVER['REQUEST_URI'], $pages);
                }
            }
        }
        
        return $this->response;
    }
    
    function addEditClient() {
        
        $actMsg['type']             = 0;
        $actMsg['message']          = '';
        
        $clientName                 = trim($this->_request['clientName']);
        $permalink                  = trim($this->_request['permalink']);
        $url                        = trim($this->_request['url']);
        $urlTarget                  = trim($this->_request['urlTarget']);
        $clientDescription          = trim($this->_request['clientDescription']);
        $status                     = trim($this->_request['status']);
        $displayOrder               = trim($this->_request['displayOrder']);
        $isShowcase                 = trim($this->_request['isShowcase']);
        
        if($clientName != '') {
            if($this->_request['IdToEdit']!= '')
                $sel_ContentDetails = $this->model->checkExistence("clientName = '".addslashes($clientName)."' AND clientId != ".$this->_request['IdToEdit']);
            else
                $sel_ContentDetails = $this->model->checkExistence("clientName = '".addslashes($clientName)."'");

            if(sizeof($sel_ContentDetails) < 1) {
                
                //permalink --------------
                $ENTITY          = TBL_CLIENT;
                if(!$permalink)
                    $permalink   = $clientName;
                else
                    $permalink   = str_replace('-', ' ', $permalink);

                if($this->_request['IdToEdit'])
                    $ExtraQryStr = 'clientId != '.$this->_request['IdToEdit'];
                else
                    $ExtraQryStr = 1;
                $permalink       = createPermalink($ENTITY, $permalink, $ExtraQryStr);
                //permalink ---------------

                $params                             = array();
                $params['clientName']               = $clientName;
                $params['permalink']                = $permalink;
                $params['url']                      = $url;
                $params['urlTarget']                = $urlTarget;
                $params['clientDescription']        = $clientDescription;
                $params['status']                   = $status;
                $params['isShowcase']               = $isShowcase;
                
                if($displayOrder == 'T' || $displayOrder == 'B'){
                    $order          = $this->model->getDisplayOrder($displayOrder);
                    $displayOrder   = ($displayOrder == 'T')? ($order['displayOrder'] - 1) : ($order['displayOrder'] + 1);
                }
                
                $params['displayOrder']             = $displayOrder;
                
                if($this->_request['IdToEdit'] != '') {

                    $this->model->clientUpdateById($params, $this->_request['IdToEdit']);

                    $actMsg['editid']           = $this->_request['IdToEdit'];
                    $actMsg['message']          = 'Data updated successfully.';
                }
                else {
                    $params['entryDate']        = date('Y-m-d H:i:s');
                    $actMsg['editid']           = $this->model->newClient($params);

                    $actMsg['message']          = 'Data inserted successfully.';
                }
                    $actMsg['type']             = 1;
                
                //Image ---------------
                $targetLocation = MEDIA_FILES_ROOT.DS.$this->_request['pageType'];
                $targetFile     = MEDIA_FILES_SRC.DS.$this->_request['pageType'];
                $ogUrl          = DS.$this->_request['pageType'];
                
                if (!file_exists($targetLocation) && !is_dir($targetLocation)) 
                    $this->createMedia($targetLocation);
                
                $settings = $this->model->settings($this->_request['pageType']);
                $settings = unserialize($settings['value']);

                if($_FILES['clientImage']['name'] && substr($_FILES['clientImage']['type'], 0, 5) == 'image') {

                    $fObj           = new FileUpload;
                    $selData      = $this->model->clientById($actMsg['editid']);

                    $TWH[0]         = $settings['imageWidth'];       // thumb width
                    $TWH[1]         = $settings['imageHeight'];      // thumb height
                    $LWH[0]         = $settings['imageWidth'];       // large width
                    $LWH[1]         = $settings['imageHeight'];      // large height
                    $option         = 'thumbnail';                  // upload, thumbnail, resize, all

                    $fileName 		= $permalink."-image";
                    if($target_image = $fObj->uploadImage($_FILES['clientImage'], $targetLocation, $fileName, $TWH, $LWH, $option)) {

                        // delete existing image
                        if($selData['clientImage'] != $target_image) {
                            @unlink($targetLocation.'/normal/'.$selData['clientImage']);
                            @unlink($targetLocation.'/thumb/'.$selData['clientImage']);
                            @unlink($targetLocation.'/large/'.$selData['clientImage']);
                        }

                        // update new image
                        $params                 = array();
                        $params['clientImage']	= $target_image;
                        $this->model->clientUpdateById($params, $actMsg['editid']);
                    }
                }
                //Image ---------------
            }
            else
                $actMsg['message']        = 'Client already exists.';   
        }
        else
        $actMsg['message']        = 'Fields marked with (*) are mandatory.';
        
		return $actMsg;
    }
    
    function createMedia($targetLocation) {
        $indexingSource = MEDIA_FILES_ROOT.DS.'index.php';
        @mkdir($targetLocation, 0755); 
        copy($indexingSource, $targetLocation.DS.'index.php');

        @mkdir($targetLocation.DS.'large',      0755); 
        copy($indexingSource, $targetLocation.DS.'large'.DS.'index.php');

        @mkdir($targetLocation.DS.'normal',     0755); 
        copy($indexingSource, $targetLocation.DS.'normal'.DS.'index.php');

        @mkdir($targetLocation.DS.'small',      0755);   
        copy($indexingSource, $targetLocation.DS.'small'.DS.'index.php');

        @mkdir($targetLocation.DS.'thumb',      0755); 
        copy($indexingSource, $targetLocation.DS.'thumb'.DS.'index.php');
    }
    
    function multiAction() {
        $actMsg['type']           = 0;
        $actMsg['message']        = '';
        
        if($this->_request['multiAction']){
            foreach($this->_request['selectMulti'] as $val) {
                
                $params = array();  
                
                switch($this->_request['multiAction']) {
                    case "1":
                        $params['status']       = 'Y';
                        break;
                    case "2":
                        $params['status']       = 'N';
                        break;
                    case "3":
                        $params['delete']       = 'Y';
                        break;
                    case "4":
                        $params['isShowcase']   = 'Y';
                        break;
                    case "5":
                        $params['isShowcase']   = 'N';
                        break;
                    default:
                        $this->response('', 406);
                } 
                
                if($params['delete'] == 'Y') {
                    $client = $this->model->clientById($val);
                    
                    if($client){
                        if($client['clientImage'] && file_exists(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$client['clientImage'])){
                            @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$category['clientImage']);
                            @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/normal/'.$category['clientImage']);
                            @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/large/'.$category['clientImage']);
                        }
                        
                        $this->model->deleteClient($val);
                    }
                }
                else
                    $this->model->clientUpdateById($params, $val);
                
                $actMsg['type']           = 1;
                $actMsg['message']        = 'Operation successful.';
            }
        }
        
        return $actMsg;
    }

    function deleteFile(){
        $actMsg['type']           = 0;
        $actMsg['message']        = '';

        if($this->_request['DeleteFile'] == 'clientImage'){
            $selData = $this->model->clientById($this->_request['IdToEdit']);
            if($selData['clientImage']){
                @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/normal/'.$selData['clientImage']);
                @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$selData['clientImage']);
                @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/large/'.$selData['clientImage']);

                // update image field to blank
                $params                     = array();
                $params['clientImage']      = '';
                $this->model->clientUpdateById($params, $this->_request['IdToEdit']);
            }

            $actMsg['type']           = 1;
            $actMsg['message']        = 'Image deleted successfully.';
        }

        return $actMsg;  
    }
    
    function swap() {
        $actMsg['type']             = 0;
        $actMsg['message']          = '';
        
        $listingCounter = 1;
        
        foreach ($this->_request['recordsArray'] as $recordID) {
            $params = array();
            $params['displayOrder'] = $listingCounter;
            $this->model->clientUpdateById($params, $recordID);
            $listingCounter = $listingCounter + 1;
        }
        
        if($listingCounter > 1){
            $actMsg['type']             = 1;
            $actMsg['message']          = 'Operation successful.';
        }
        
        return $actMsg;
    }
    
    function modPage(){
        $srch = trim($this->_request['srch']);
        if($srch) {
            return $this->model->searchLinkedPages($this->_request['mid'], $this->_request['pageType'], $srch, 0, 10);
        }
    }
}