<?php defined('BASE') OR exit('No direct script access allowed.');
class ClientsettingsController extends REST
{
    private    $model;
	protected  $response = array();
	
    public function __construct($model) {
    	parent::__construct();
        $this->model        = new $model;
    }
    
	function index($act = []) {
        
        $settings     = $this->model->settings($this->_request['pageType']);
        
        $this->response['settings'] = unserialize($settings['value']);
        
        return $this->response;
    }
    
    function addEditSettings() {
        $actMsg['type']                 = 0;
        $actMsg['message']              = '';
        
        $isImage                        = 1;
        $imageWidth                     = trim($this->_request['imageWidth']);
        $imageHeight                    = trim($this->_request['imageHeight']);

        $limit                          = trim($this->_request['limit']);

        $isShowcase                     = isset($this->_request['isShowcase']) ? 1 : 0;
        $showcaseTitle                  = trim($this->_request['showcaseTitle']);
        $showcaseNo                     = trim($this->_request['showcaseNo']);
        $showcaseDescription            = trim($this->_request['showcaseDescription']);
        
        $error                          = 0;
        if($isBanner == '1') {
            if(!$bannerWidth || !$bannerHeight){
                $error                  = 1;
                $actMsg['message']      = 'Please provide width and height for Banner.';
            }
        }

        if($isImage == '1') {
            if(!$imageWidth || !$imageHeight){
                $error                  = 1;
                $actMsg['message']      = 'Please provide width and height for Image.';
            }
        }

        if($isShowcase == '1') {
            if(!$showcaseTitle || $showcaseNo < 1){
                $error                  = 1;
                $actMsg['message']      = 'Please provide title and number of item for Showcase.';
            }
        }
        
        if(!$error){
            $paramsContact                          = array();
            
            $paramsContact['isImage']               = $isImage;
            $paramsContact['imageWidth']            = $imageWidth;
            $paramsContact['imageHeight']           = $imageHeight;

            $paramsContact['limit']                 = $limit;

            $paramsContact['isShowcase']            = $isShowcase;
            $paramsContact['showcaseTitle']         = $showcaseTitle;
            $paramsContact['showcaseNo']            = $showcaseNo;
            $paramsContact['showcaseDescription']   = $showcaseDescription;
            
            $params                     = [];
            $params['value']            = serialize($paramsContact);
            
            $exist                      = $this->model->settings($this->_request['pageType']);
            
            if(!$exist) {
                
                $params['name']         = $this->_request['pageType'];
                $this->model->newSettings($params);
                $actMsg['message']      = 'Data inserted successfully.';
                
            } else {
                
                $this->model->updateSetting($this->_request['pageType'], $params);
                $actMsg['message']      = 'Data updated successfully.';
            }

            $actMsg['type']             = 1;
        }
        
        return $actMsg;
    }
}