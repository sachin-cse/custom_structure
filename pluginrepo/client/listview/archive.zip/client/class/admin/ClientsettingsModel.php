<?php defined('BASE') OR exit('No direct script access allowed.');
class ClientsettingsModel extends CommunicationsettingsModel
{

}