<?php defined('BASE') OR exit('No direct script access allowed.');
class ClientModel extends ContentModel
{
    function clientById($id) {
		$ExtraQryStr = "clientId = ".addslashes($id);
		return $this->selectSingle(TBL_CLIENT, "*", $ExtraQryStr);
	}
	
    function clientByPermalink($permalink) {
		$ExtraQryStr = "permalink = '".addslashes($permalink)."'";
		return $this->selectSingle(TBL_CLIENT, "*", $ExtraQryStr);
	}
    
    function clientCount($ExtraQryStr) {
		$ExtraQryStr .= " AND status = 'Y'";
        return $this->rowCount(TBL_CLIENT, "clientId", $ExtraQryStr);
	}
    
    function getClientByLimit($ExtraQryStr, $start, $limit) {
		$ExtraQryStr .= " AND status = 'Y' ORDER BY displayOrder";
		return $this->selectMulti(TBL_CLIENT, "*", $ExtraQryStr, $start, $limit); 	
	}
    
    function getClientList($ExtraQryStr) {
		$ExtraQryStr .= " AND status = 'Y' ORDER BY displayOrder";
		return $this->selectAll(TBL_CLIENT, "clientName, permalink", $ExtraQryStr); 	
	}
	
	/* ----------------------------------------- TBL_SETTINGS ------------------------------------------------ */
	function settings($name) {
        $ExtraQryStr = "name = '".addslashes($name)."'";
		$settings = $this->selectSingle(TBL_SETTINGS, "value", $ExtraQryStr);
        
        return $settings;
    }
    
    function newContact($params){
        return $this->insertQuery(TBL_CONTACT, $params);
	}
}