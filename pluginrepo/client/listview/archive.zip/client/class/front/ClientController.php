<?php defined('BASE') OR exit('No direct script access allowed.');
class ClientController extends REST
{
    private    $model;
	protected  $pageview;
	protected  $response = array();
	private    $settings = array();
	
    public function __construct($model) {
    	parent::__construct();
        $this->model        = new $model;
    }
    
	function index($pageData = []) {
        
        if($this->_request['dtaction'])
            return;
		
        if($pageData) {
            
            $this->pageData     = $pageData;
            
            $settings           = $this->model->settings($pageData['parent_dir']);
            $settings           = unserialize($settings['value']);
            $settings['name']   = $pageData['parent_dir'];
            $this->settings     = $settings;
            
            $this->response['pageContent']  = $this->content($pageData['categoryId']);
            
            $records                        = $this->client();
            $itemList                       = $this->itemList($records);
            $this->response['itemList']     = implode($itemList);

            $this->pageview                 = 'index.php';
            
            if($this->pageview) {

                $this->response['body']     = $this->pageview;
                $this->response['pageData'] = $pageData;
                return $this->response; 
            }
        }
    }
    
    function client() {
        
        $ExtraQryStr                    	 = 1;
		$this->response['rowCount']			 = $this->model->clientCount($ExtraQryStr);
		
		if($this->response['rowCount']) {
                
			$p                               = new Pager;
			$this->response['limit']         = ($this->settings['limit'])? $this->settings['limit'] : VALUE_PER_PAGE;
			$start                           = $p->findStart($this->response['limit'], $this->_request['page']);
			$pages                           = $p->findPages($this->response['rowCount'], $this->response['limit']);

			$records   	                     = $this->model->getClientByLimit($ExtraQryStr, $start, $this->response['limit']);

			if(ceil($this->response['rowCount'] / $this->response['limit']) > 1) {
				$this->response['page']      = ($this->_request['page']) ? $this->_request['page'] : 1;
				$this->response['totalPage'] = ceil($this->response['rowCount'] / $this->response['limit']);

				$this->response['pageList']  = $p->pageList($this->response['page'], $_SERVER['REQUEST_URI'], $pages);
            }
            
            return $records;
		}
    }
    
    function content($categoryId) {
            
        $rsArry 				            = [];

        $rsArry['contentCount']	            = $this->model->countContentbymenucategoryId($categoryId);

        if($rsArry['contentCount']) {

            $p                              = new Pager;
            $rsArry['contentLimit']         = VALUE_PER_PAGE;
            $start                          = $p->findStart($rsArry['contentLimit'], $this->_request['contentPage']);
            $contentPages                   = $p->findPages($rsArry['contentCount'], $rsArry['contentLimit']);

            $rsArry['content']              = $this->model->getContentbymenucategoryId($categoryId, $start, $rsArry['contentLimit']);

            if($rsArry['contentCount'] > 0 && ceil($rsArry['contentCount'] / $rsArry['contentLimit']) > 1) {
                
                $rsArry['contentPage']      = ($this->_request['contentPage']) ? $this->_request['contentPage'] : 1;
                $rsArry['totalContentPage'] = ceil($rsArry['contentCount'] / $rsArry['contentLimit']);

                $rsArry['contentPageList']  = $p->pageList($rsArry['contentPage'], $_SERVER['REQUEST_URI'], $contentPages);
            }
    	    return $rsArry;
        }
    }
	    
    function ajx_action($pageData = []){
        
    }
    
    function showcase($opt = []) {
        
        $settings           = $this->model->settings($opt['module']);
        $settings           = unserialize($settings['value']);
        $settings['name']   = $opt['module'];
        $this->settings     = $settings;
        
        if($settings['isShowcase']) {
        
            $showcaseFile           = CACHE_ROOT.DS.'client_showcase.html';
            if(file_exists($showcaseFile)) {
                include $showcaseFile;
                return;
            }

            $limit      = ($settings['showcaseNo'])? $settings['showcaseNo'] : 3;
            $records	= $this->model->getClientByLimit("isShowcase = 'Y'", 0, $limit);

            if($records) {

                $wrapcss    = ($opt['wrapcss']) ?   $opt['wrapcss'] : '';
                $css        = ($opt['css']) ?       $opt['css']     : '';
                $col        = ($opt['col'])?        $opt['col']     : 'col-sm-4 col-xs-6';
                $slider     = ($opt['slider'])?     $opt['slider']  : false;
                $withIcon   = ($settings['isIcon'])?'withIcon'      : '';

                $this->result[]   = '<section class="section '.$wrapcss.'">
                                        <div class="container">
                                            <h2 class="heading">'.headingModify($settings['showcaseTitle']).'</h2>';

                if(trim($settings['showcaseDescription'])) {
                    $this->result[]   = '<div class="sk_content_wrap mb30">
                                        <div class="sk_content">
                                            <div class="editor_text">
                                                '.$settings['showcaseDescription'].'
                                            </div>
                                        </div>
                                    </div>';
                }

                $this->result[]   = '<div class="'.$css.'">';
                
                $this->itemList($records, $col, $slider);
                
                $this->result[] = '</div></div></section>';

                $html = implode($this->result);

                echo $html;
            }
        }
    }
    
    function itemList($records, $col = 'col-sm-3 col-xs-4', $slider = false) {
        
        if($slider === true){
            $this->result[]     = '<div class="owl-carousel">';
            $itemElem           = '<div class="item">'; 
            $itemElemEnd        = '</div>'; 
            $itemElemWrapEnd    = '</div><script defer="" type="text/javascript">
                                        function loadOwlClient(){
                                        if(window.jQuery){
                                            $(".sk_list .owl-carousel").owlCarousel({ 
                                                items: 5,
                                                loop: false,
                                                autoplay: false,
                                                autoplayHoverPause: true,
                                                autoplayTimeout: 3000,
                                                smartSpeed: 1000,
                                                margin: 30,
                                                dots: false,
                                                nav: true,
                                                navElement: \'div\',
                                                navText: ["<i class=\'fa fa-angle-left\'></i>", "<i class=\'fa fa-angle-right\'></i>"],
                                                lazyLoad: true,
                                                responsive: {
                                                    0: { items: 2 },
                                                    480: { items: 2 },
                                                    600: { items: 3 },
                                                    768: { items: 4 },
                                                    992: { items: 5 },
                                                    1600: { items: 5 }
                                                }, 
                                            });} else {setTimeout(function(){ loadOwlClient();}, 50);}}loadOwlClient();</script>'; 
            $lazyClass          = 'owl-lazy';
        } else {
            $this->result[]     = '<ul class="ul row">';
            $itemElem           = '<li class="'.$col.'">';
            $itemElemEnd        = '</li>'; 
            $itemElemWrapEnd    = '</ul>'; 
            $lazyClass          = 'lazy';
        }
        
        foreach($records as $data) {
            
            $link = ($data['url'])? $data['url']:'#';

            $figureImg = '';

            if( $this->settings['isImage'] ) {

                if( $data['clientImage'] && file_exists(MEDIA_FILES_ROOT.DS.$this->settings['name'].DS.'thumb'.DS.$data['clientImage']) )
                    $figSrc = MEDIA_FILES_SRC.'/'.$this->settings['name'].'/thumb/'.$data['clientImage'];
                else
                    $figSrc = STYLE_FILES_SRC.'/images/noimage.png';

                $figureImg = '<figure>
                            <img class="'.$lazyClass.'" src="'.STYLE_FILES_SRC.'/images/blank.png" data-src="'.$figSrc.'" alt="'.$data['clientName'].'">
                        </figure>';
            }

            $this->result[] = sprintf('%s
                        <div class="sk_box">
                            <a aria-label="%s" href="%s" target="_blank" rel="noopener noreferrer nofollow">%s</a>
                        </div>
                    %s', $itemElem, $data['clientName'], $link, $figureImg, $itemElemEnd);
        }
        
        $this->result[]   = $itemElemWrapEnd;

        return $this->result;
    }
}