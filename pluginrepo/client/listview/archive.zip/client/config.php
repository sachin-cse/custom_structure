<?php 
defined('BASE') OR exit('No direct script access allowed');
$dbArr = array(
        "TBL_CLIENT" => "tbl_client"
);