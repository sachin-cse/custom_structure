<?php
defined('BASE') OR exit('No direct script access allowed.');
class FaqController extends REST
{
	private    $model;
	protected  $pageview;
	protected  $response = array();
	
    public function __construct($model) {
    	parent::__construct();
        $this->model        = new $model;
    }
    
	function index($pageData = '') {
        
        if($this->_request['dtaction'])
            return;
		
        if($pageData) {

            $this->response['pageContent']       = $this->content($pageData['categoryId']);
        
            $ExtraQryStr                    	 = 1;
            $this->response['rowCount']			 = $this->model->faqCount($ExtraQryStr);

            if($this->response['rowCount']) {

                $p                               = new Pager;
                $this->response['limit']         = VALUE_PER_PAGE;
                $start                           = $p->findStart($this->response['limit'], $this->_request['page']);
                $pages                           = $p->findPages($this->response['rowCount'], $this->response['limit']);

                $this->response['faqs']  	 	 = $this->model->getFaq($ExtraQryStr, $start, $this->response['limit']);

                if($this->response['rowCount'] > 0 && ceil($this->response['rowCount'] / $this->response['limit']) > 1) {
                    
                    $this->response['page']      = ($this->_request['page']) ? $this->_request['page'] : 1;
                    $this->response['totalPage'] = ceil($this->response['rowCount'] / $this->response['limit']);

                    $this->response['pageList']  = $p->pageList($this->response['page'], $_SERVER['REQUEST_URI'], $pages);
                }
            }

            $this->pageview         = 'index.php';
            $this->response['body'] = $this->pageview;

            return $this->response; 
        }
    }
	
    function content($categoryId) {
            
        $rsArry 				            = [];

        $rsArry['contentCount']	            = $this->model->countContentbymenucategoryId($categoryId);

        if($rsArry['contentCount']) {

            $p                              = new Pager;
            $rsArry['contentLimit']         = VALUE_PER_PAGE;
            $start                          = $p->findStart($rsArry['contentLimit'], $this->_request['contentPage']);
            $contentPages                   = $p->findPages($rsArry['contentCount'], $rsArry['contentLimit']);

            $rsArry['content']              = $this->model->getContentbymenucategoryId($categoryId, $start, $rsArry['contentLimit']);

            if($rsArry['contentCount'] > 0 && ceil($rsArry['contentCount'] / $rsArry['contentLimit']) > 1) {
                
                $rsArry['contentPage']      = ($this->_request['contentPage']) ? $this->_request['contentPage'] : 1;
                $rsArry['totalContentPage'] = ceil($rsArry['contentCount'] / $rsArry['contentLimit']);

                $rsArry['contentPageList']  = $p->pageList($rsArry['contentPage'], $_SERVER['REQUEST_URI'], $contentPages);
            }
    	    return $rsArry;
        }
    }
    
    function ajx_action() {
        
    }
}
?>