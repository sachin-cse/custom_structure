<?php
defined('BASE') OR exit('No direct script access allowed.');
class FaqModel extends ContentModel
{
    function faqById($id) {
		$ExtraQryStr = "faqId = ".addslashes($id);
		return $this->selectSingle(TBL_FAQ, "*", $ExtraQryStr);
	}
    
    function faqCount($ExtraQryStr) {
		$ExtraQryStr .= " AND status = 'Y'";
        return $this->rowCount(TBL_FAQ, "faqId", $ExtraQryStr);
	}
    
    function getFaq($ExtraQryStr, $start, $limit) {
		$ExtraQryStr .= " AND status = 'Y' ORDER BY displayOrder";
		return $this->selectMulti(TBL_FAQ, "*", $ExtraQryStr, $start, $limit); 	
	}
}
?>