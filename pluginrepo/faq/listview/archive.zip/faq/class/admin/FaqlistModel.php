<?php
defined('BASE') OR exit('No direct script access allowed.');
class FaqlistModel extends Site
{
    function getDisplayOrder($orderBy = 'T'){
        $ENTITY         = TBL_FAQ;
        $ExtraQryStr    = 1;
        
        if($orderBy == 'T')
            $str = 'MIN(displayOrder) displayOrder';
        elseif($orderBy == 'B')
            $str = 'MAX(displayOrder) displayOrder';
        else
            return;
        
		return $this->selectSingle($ENTITY, $str, $ExtraQryStr, $start, $limit); 
    }
    
    
    function checkExistence($ExtraQryStr) {
        return $this->selectSingle(TBL_FAQ, "*", $ExtraQryStr);
    }
    
    function newFaq($params) {
        return $this->insertQuery(TBL_FAQ, $params);
	}
    
	function faqById($id) {
		$ExtraQryStr = "faqId = ".addslashes($id);
		return $this->selectSingle(TBL_FAQ, "*", $ExtraQryStr);
	}
    
    function faqCount($ExtraQryStr) {
        return $this->rowCount(TBL_FAQ, "faqId", $ExtraQryStr);
	}
    
    function getFaqByLimit($ExtraQryStr, $start, $limit) {
		$ExtraQryStr .= " ORDER BY displayOrder";
		return $this->selectMulti(TBL_FAQ, "*", $ExtraQryStr, $start, $limit); 	
	}
	
    function faqUpdateById($params, $id){
        $CLAUSE = "faqId = ".addslashes($id);
        return $this->updateQuery(TBL_FAQ, $params, $CLAUSE);
    }
    
    function deleteFaq($id){
        return $this->executeQuery("DELETE FROM ".TBL_FAQ." WHERE faqId = ".addslashes($id));
    }
    
    function searchLinkedPages($mid, $parent_dir, $srch, $start, $limit) {
        
        if($mid == 0) {
            
            $ExtraQryStr    = "mc.categoryName like '%".addslashes($srch)."%'";
            $ENTITY         = TBL_MENU_CATEGORY." mc JOIN ".TBL_MODULE." m ON (m.menu_id = mc.moduleId)";
            $ExtraQryStr   .= " AND mc.status = 'Y' AND m.parent_dir = '".addslashes($parent_dir)."' AND m.child_dir = '' ORDER BY mc.displayOrder";
            
            $data = $this->selectMulti($ENTITY, "mc.categoryId id, mc.categoryName page, mc.permalink", $ExtraQryStr, $start, $limit);
            
        } else {  
            
            $ExtraQryStr = " status = 'Y' AND faqName like '".addslashes($srch)."%' ORDER BY faqName ASC";
            $data        = $this->selectMulti(TBL_FAQ, "faqId id, faqName page, permalink", $ExtraQryStr, $start, $limit);
            
        }

		return $data;
    }
}
?>