<?php 
defined('BASE') OR exit('No direct script access allowed');
$dbArr = array(
    "TBL_FAQ"                         => "tbl_faq"
);
