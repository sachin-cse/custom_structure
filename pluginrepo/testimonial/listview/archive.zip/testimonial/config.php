<?php 
defined('BASE') OR exit('No direct script access allowed');
$dbArr = array(
    "TBL_TESTIMONIAL"                         => "tbl_testimonial"
);