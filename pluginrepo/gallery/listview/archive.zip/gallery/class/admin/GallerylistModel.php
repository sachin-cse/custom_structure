<?php defined('BASE') OR exit('No direct script access allowed.');
class GallerylistModel extends Site
{
    function getDisplayOrder($orderBy = 'T'){
        $ENTITY         = TBL_GALLERY;
        $ExtraQryStr    = 1;
        
        if($orderBy == 'T')
            $str = 'MIN(displayOrder) displayOrder';
        elseif($orderBy == 'B')
            $str = 'MAX(displayOrder) displayOrder';
        else
            return;
        
		return $this->selectSingle($ENTITY, $str, $ExtraQryStr, $start, $limit); 
    }

    function getLinkedPages($parent_dir, $start, $limit){
        $ENTITY         = TBL_MENU_CATEGORY." mc JOIN ".TBL_MODULE." m ON (m.menu_id = mc.moduleId)";
        $ExtraQryStr    = "mc.status = 'Y' AND m.parent_dir = '".addslashes($parent_dir)."' AND m.child_dir = '' ORDER BY mc.displayOrder";
        
		return $this->selectMulti($ENTITY, "mc.categoryId, mc.categoryName, mc.permalink", $ExtraQryStr, $start, $limit); 
    }

    function checkExistence($ExtraQryStr) {
        return $this->selectSingle(TBL_GALLERY, "*", $ExtraQryStr);
    }
    
    function newGallery($params) {
        return $this->insertQuery(TBL_GALLERY, $params);
	}
    
	function albumById($id) {
		$ExtraQryStr = "id = ".addslashes($id);
		return $this->selectSingle(TBL_GALLERY, "galleryName, galleryDescription, galleryDate", $ExtraQryStr);
	}
    
    function getNoneAlbum() {
		$ExtraQryStr = "galleryName = '' AND permalink='none' AND parentId = 0";
		return $this->selectSingle(TBL_GALLERY, "id", $ExtraQryStr);
	}
    
	function galleryById($id) {
		$ExtraQryStr = "id = ".addslashes($id);
		return $this->selectSingle(TBL_GALLERY, "*", $ExtraQryStr);
	}
    
    function galleryCount($ExtraQryStr) {
        return $this->rowCount(TBL_GALLERY, "id", $ExtraQryStr);
	}
    
    function getGalleryByLimit($ExtraQryStr, $start, $limit) {
		$ExtraQryStr .= " ORDER BY groupDate, displayOrder";
		return $this->selectMulti(TBL_GALLERY, "*", $ExtraQryStr, $start, $limit); 	
	}
    
    function getParentGalleryByLimit($ExtraQryStr, $start, $limit) {
		$ExtraQryStr .= " AND parentId = 0  ORDER BY galleryName";
		return $this->selectMulti(TBL_GALLERY, "*", $ExtraQryStr, $start, $limit); 	
	}
	
    function galleryUpdateById($params, $id){
        $CLAUSE = "id = ".addslashes($id);
        return $this->updateQuery(TBL_GALLERY, $params, $CLAUSE);
    }
    
    function deleteGallery($id){
        return $this->executeQuery("DELETE FROM ".TBL_GALLERY." WHERE id = ".addslashes($id));
    }
	
	/* ----------------------------------------- FOR_MENU ----------------------------------------- */
    function searchLinkedPages($mid, $parent_dir, $srch, $start, $limit) {
        
        if($mid == 0) {
            
            $ExtraQryStr    = "mc.categoryName LIKE '%".addslashes($srch)."%'";
            $ENTITY         = TBL_MENU_CATEGORY." mc JOIN ".TBL_MODULE." m ON (m.menu_id = mc.moduleId)";
            $ExtraQryStr   .= " AND mc.status = 'Y' AND m.parent_dir = '".addslashes($parent_dir)."' AND m.child_dir = '' ORDER BY mc.displayOrder";
            
            $data = $this->selectMulti($ENTITY, "mc.categoryId id, mc.categoryName page, mc.permalink", $ExtraQryStr, $start, $limit);
            
        } else {
            
            $ExtraQryStr = " status = 'Y' AND galleryName LIKE '".addslashes($srch)."%' ORDER BY galleryName ASC";
            $data        = $this->selectMulti(TBL_GALLERY, "id id, galleryName page, permalink", $ExtraQryStr, $start, $limit);
            
        }

		return $data;
    }
    
    function settings($name) {
        $ExtraQryStr = "name = '".addslashes($name)."'";
		return $this->selectSingle(TBL_SETTINGS, "*", $ExtraQryStr);
    }
}