<?php defined('BASE') OR exit('No direct script access allowed.');
class GallerysettingsModel extends CommunicationsettingsModel
{

}