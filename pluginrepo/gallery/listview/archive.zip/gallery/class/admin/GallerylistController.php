<?php defined('BASE') OR exit('No direct script access allowed.');
class GallerylistController extends REST
{
    private    $model;
	protected  $response = array();
	
    public function __construct($model) {
    	parent::__construct();
        $this->model        = new $model;
    }
    
	function index($act = []) {
            
        $this->response['linkedPages'] = $this->model->getLinkedPages($this->_request['pageType'], 0, 100);
        
        $albums                        = $this->model->getParentGalleryByLimit(1, 0, 100);
        $this->response['albums']      = ($albums)? $albums : $this->setDefaultAlbum();
            
        $settings                      = $this->model->settings($this->_request['pageType']);
        $this->response['settings']    = unserialize($settings['value']);
        
        if( isset($this->_request['editid']) || isset($act['editid']) || $this->_request['dtaction'] == 'add' ) {
            
            $editid                        = ($this->_request['editid'])? $this->_request['editid']:$act['editid'];
            
            if($editid) {
                $this->response['record']  = $this->model->galleryById($editid);

                $titleandMetaUrl           = '/'.$this->response['record']['permalink'].'/'.$this->response['record']['menuPermalink'].'/';
                $seoModel                  = new TitlemetaModel;
                $this->response['seoData'] = $seoModel->titleMetaByUrl($titleandMetaUrl);
            }
        }
        else {
        
            $ExtraQryStr = 1;

            // SEARCH START --------------------------------------------------------------
            if(isset($this->_request['searchText']))
                $this->session->write('searchText', $this->_request['searchText']);

            if($this->session->read('searchText'))
                $ExtraQryStr        .= " AND galleryName LIKE '%".addslashes($this->session->read('searchText'))."%'";

            if(isset($this->_request['searchStatus']))
                $this->session->write('searchStatus', $this->_request['searchStatus']);

            if($this->session->read('searchStatus'))
                $ExtraQryStr        .= " AND status = '".addslashes($this->session->read('searchStatus'))."'";

            if(isset($this->_request['searchShowcase']))
                $this->session->write('searchShowcase', $this->_request['searchShowcase']);

            if($this->session->read('searchShowcase'))
                $ExtraQryStr        .= " AND isShowcase = '".addslashes($this->session->read('searchShowcase'))."'";

            if(isset($this->_request['searchAlbum']))
                $this->session->write('searchAlbum', $this->_request['searchAlbum']);

            if($this->session->read('searchAlbum'))
                $ExtraQryStr        .= " AND (parentId = '".addslashes($this->session->read('searchAlbum'))."' OR id = '".addslashes($this->session->read('searchAlbum'))."')";

            if(isset($this->_request['Reset']) || isset($this->_request['Search'])) {

                if(isset($this->_request['Reset'])) {

                    $this->session->write('searchText',     '');
                    $this->session->write('searchStatus',   '');
                    $this->session->write('searchShowcase', '');
                    $this->session->write('searchAlbum',    '');
                }

                $this->model->redirectToUrl(SITE_ADMIN_PATH.'/index.php?pageType='.$this->_request['pageType'].'&dtls='.$this->_request['dtls'].'&moduleId='.$this->_request['moduleId']);
            }
            // SEARCH END ----------------------------------------------------------------

            $this->response['rowCount']     = $this->model->galleryCount($ExtraQryStr);

            if($this->response['rowCount']) {

                $p                          = new Pager;
                $this->response['limit']    = VALUE_PER_PAGE;
                $start                      = $p->findStart($this->response['limit'], $this->_request['page']);
                $pages                      = $p->findPages($this->response['rowCount'], $this->response['limit']);

                $this->response['records']    	 = $this->model->getGalleryByLimit($ExtraQryStr, $start, $this->response['limit']);

                if($this->response['rowCount'] > 0 && ceil($this->response['rowCount'] / $this->response['limit']) > 1) {
                    $this->response['page']      = ($this->_request['page']) ? $this->_request['page'] : 1;
                    $this->response['totalPage'] = ceil($this->response['rowCount'] / $this->response['limit']);

                    $this->response['pageList']  = $p->pageList($this->response['page'], $_SERVER['REQUEST_URI'], $pages);
                }
            }
        }
        
        return $this->response;
    }

    function getAlbum() {
        
        $actMsg['type']                 = 0;
        $actMsg['message']              = '';
            
        $id                             = trim($this->_request['id']);
        
        if($id) {
            $record                     = $this->model->albumById($id);
            $actMsg['albumDate']        = date('Y-m-d',strtotime($record['galleryDate']));
            $actMsg['albumName']        = $record['galleryName'];
            $actMsg['albumDescription'] = $record['galleryDescription'];

            $actMsg['type']             = 1;
        }
        
		return $actMsg;
    }

    function uploadPhotos() {
        
        $actMsg['type']             = 0;
        $actMsg['message']          = '';
        
        $error = 0;

        $targetLocation = MEDIA_FILES_ROOT.DS.$this->_request['pageType'];

        if (!file_exists($targetLocation) && !is_dir($targetLocation)) 
            $this->createMedia($targetLocation);

        $settings = $this->model->settings($this->_request['pageType']);
        $settings = unserialize($settings['value']);

        $parentId           = trim($this->_request['parentId']);
        $albumName          = trim($this->_request['albumName']);
        $albumDescription   = trim($this->_request['albumDescription']);
        $albumDate          = trim($this->_request['albumDate']);
        $albumDate          = (strtotime($albumDate) > 0)? $albumDate : date('Y-m-d');

        if(!$settings['isAlbum']){
            $noneAlb    = $this->model->getNoneAlbum();
            $parentId   = $noneAlb['id'];
            
            if(!$parentId) {

                $error = 1;
                $actMsg['message']      = 'Oops! Something went wrong. Please close your browser window and try again.';
            }
        }
        else {
            if($albumName) {
                //permalink --------------
                $ENTITY             = TBL_GALLERY;
                if($parentId)
                    $ExtraQryStr = 'id != '.$parentId;
                else
                    $ExtraQryStr = 1;
                $permalink          = $albumName;
                $permalink          = createPermalink($ENTITY, $permalink, $ExtraQryStr);
                //permalink ---------------

                $params                       = array();
                $params['galleryName']        = $albumName;
                $params['permalink']          = $permalink;
                $params['galleryDescription'] = $albumDescription;
                $params['galleryDate']        = $albumDate;

                if(!$parentId) {
                    $params['galleryImage']         = '';
                    $params['status']               = 'Y';
                    $params['entryDate']            = date('Y-m-d H:i:s');
                    $params['groupDate']            = date('Y-m-d H:i:s');
                    $parentId                       = $this->model->newGallery($params);
                }
                else 
                    $this->model->galleryUpdateById($params, $parentId);
            }else{
                if(!$parentId) {

                    $error = 1;
                    $actMsg['message']      = 'Please provide a name for the album or select none.';
                }
            }
        }

        if($parentId) {

            $album          = $this->model->galleryById($parentId);

            $scsImgArr      = $errImgArr = array();
            $fObj 			= new FileUpload;

            $TWH[0]         = $settings['imageThumbWidth'];     // thumb width
            $TWH[1]         = $settings['imageThumbHeight'];    // thumb height
            $LWH[0]         = $settings['imageWidth'];          // large width
            $LWH[1]         = $settings['imageHeight'];         // large height
            $option         = 'all';                            // upload, thumbnail, resize, all

            foreach( $_FILES['galleryImage']['name'] as $imgKey=>$nameValue ) {

                if(in_array($_FILES['galleryImage']['name'][$imgKey], $this->_request['ts'])) {

                    $imgValue['name']      = $_FILES['galleryImage']['name'][$imgKey];
                    $imgValue['type']      = $_FILES['galleryImage']['type'][$imgKey];
                    $imgValue['tmp_name']  = $_FILES['galleryImage']['tmp_name'][$imgKey];
                    $imgValue['error']     = $_FILES['galleryImage']['error'][$imgKey];
                    $imgValue['size']      = $_FILES['galleryImage']['size'][$imgKey];

                    if($imgValue['name'] && substr($imgValue['type'], 0, 5) == 'image') {

                        $galleryName        = trim($this->_request['galleryName'][$imgKey]);
                        $galleryDescription = trim($this->_request['galleryDescription'][$imgKey]);

                        //permalink --------------
                        $ENTITY             = TBL_GALLERY;
                        $permalink          = ($galleryName) ? $galleryName.' '.$imgKey : time().' '.$imgKey;

                        $ExtraQryStr        = 1;
                        $permalink          = createPermalink($ENTITY, $permalink, $ExtraQryStr);
                        //permalink ---------------

                        $fileName           = $permalink;
                        if($target_image = $fObj->uploadImage($imgValue, $targetLocation, $fileName, $TWH, $LWH, $option)) {

                            $scsImgArr[] 				    = $imgValue['name'];

                            $params                         = array();
                            $params['parentId']             = $parentId;
                            $params['galleryName']          = $galleryName;
                            $params['permalink']            = $permalink;
                            $params['galleryDescription']   = $galleryDescription;
                            $params['galleryImage']         = $target_image;
                            $params['status']               = 'Y';
                            $params['entryDate']            = date('Y-m-d H:i:s');
                            $params['galleryDate']          = $albumDate;
                            $params['groupDate']            = $album['groupDate'];

                            $insertGal                      = $this->model->newGallery($params);

                            if($imgKey == 0)
                                $albumImage                 = $target_image;
                        }
                        else
                            $errImgArr[] = $imgValue['name'];
                    }
                    else
                        $errImgArr[] = $imgValue['name'];
                }
            }

            if($albumName) {
                $params                         = array();
                $params['galleryImage']         = $albumImage;

                $this->model->galleryUpdateById($params, $parentId);
            }

            $actMsg['message']      = 'Data inserted successfully.';
            $actMsg['type']         = 1;
        }
        
		return $actMsg;
    }
    
    function addEditGallery() {
        
        $actMsg['type']             = 0;
        $actMsg['message']          = '';
        $error = 0;
        
        $settings = $this->model->settings($this->_request['pageType']);
        $settings = unserialize($settings['value']);
        
        $parentId                      = trim($this->_request['parentId']);
        $galleryName                   = trim($this->_request['galleryName']);
        $permalink                     = trim($this->_request['permalink']);
        $galleryDescription            = trim($this->_request['galleryDescription']);
        $status                        = trim($this->_request['status']);
        $isShowcase                    = trim($this->_request['isShowcase']);
        $displayOrder                  = trim($this->_request['displayOrder']);
        $galleryDate                   = trim($this->_request['galleryDate']);
        
        if(!$settings['isAlbum']){
            $noneAlb    = $this->model->getNoneAlbum();
            $parentId   = $noneAlb['id'];
            if(!$parentId) {
                $error = 1;
                $actMsg['message']      = 'Oops! Something went wrong. Please close your browser window and try again.';
            }
        }
        
        
        if(!$error) {  
            if($parentId){
                //permalink --------------
                $ENTITY          = TBL_GALLERY;
                if(!$permalink)
                    $permalink   = $galleryName;
                else
                    $permalink   = str_replace('-', ' ', $permalink);

                if($this->_request['IdToEdit']){
                    $dataBeforeUpdate = $this->model->galleryById($this->_request['IdToEdit']);
                    $fileName    = $dataBeforeUpdate['galleryImage'];
                    $ExtraQryStr = 'id != '.$this->_request['IdToEdit'];
                }
                else
                    $ExtraQryStr = 1;
                $permalink       = createPermalink($ENTITY, $permalink, $ExtraQryStr);
                //permalink ---------------

                $params                             = array();
                $params['parentId']                 = $parentId;
                $params['galleryName']              = $galleryName;
                $params['permalink']                = $permalink;
                $params['galleryDescription']       = $galleryDescription;
                $params['status']                   = $status;
                $params['isShowcase']               = $isShowcase;

                if($displayOrder == 'T' || $displayOrder == 'B'){
                    $order          = $this->model->getDisplayOrder($displayOrder);
                    $displayOrder   = ($displayOrder == 'T')? ($order['displayOrder'] - 1) : ($order['displayOrder'] + 1);
                }

                $params['displayOrder']            = $displayOrder;
                $params['galleryDate']             = $galleryDate;

                $album                             = $this->model->galleryById($parentId);
                $params['groupDate']             = $album['groupDate'];

                if($this->_request['IdToEdit'] != '') {

                    $this->model->galleryUpdateById($params, $this->_request['IdToEdit']);

                    $actMsg['editid']           = $this->_request['IdToEdit'];
                    $actMsg['message']          = 'Data updated successfully.';
                }
                else {
                    $params['entryDate']        = date('Y-m-d H:i:s');
                    $actMsg['editid']           = $this->model->newGallery($params);

                    $actMsg['message']          = 'Data inserted successfully.';
                }
                    $actMsg['type']             = 1;

                //Image ---------------
                $targetLocation = MEDIA_FILES_ROOT.DS.$this->_request['pageType'];
                $targetFile     = MEDIA_FILES_SRC.DS.$this->_request['pageType'];
                $ogUrl          = DS.$this->_request['pageType'];

                if (!file_exists($targetLocation) && !is_dir($targetLocation)) 
                    $this->createMedia($targetLocation);

                $selData      = $this->model->galleryById($actMsg['editid']);
                $setCover     = $selData['galleryImage'];

                $fObj         = new FileUpload;

                if($_FILES['galleryImage']['name'] && substr($_FILES['galleryImage']['type'], 0, 5) == 'image') {

                    $TWH[0]         = $settings['imageThumbWidth'];     // thumb width
                    $TWH[1]         = $settings['imageThumbHeight'];    // thumb height
                    $LWH[0]         = $settings['imageWidth'];          // large width
                    $LWH[1]         = $settings['imageHeight'];         // large height
                    $option         = 'all';                            // upload, thumbnail, resize, all

                    $fileName		= $permalink.time();
                    if($fileName = $fObj->uploadImage($_FILES['galleryImage'], $targetLocation, $fileName, $TWH, $LWH, $option)) {

                        // delete existing image
                        if($selData['galleryImage'] != $fileName) {
                            @unlink($targetLocation.'/normal/'.$selData['galleryImage']);
                            @unlink($targetLocation.'/thumb/'.$selData['galleryImage']);
                            @unlink($targetLocation.'/large/'.$selData['galleryImage']);
                        }

                        // update new image
                        $params                  = array();
                        $params['galleryImage'] = $fileName;
                        $this->model->galleryUpdateById($params, $actMsg['editid']);
                    }
                }

                if($this->_request['w'] && $this->_request['h']) {
                    $src        = $targetLocation.DS.'normal'.DS.$fileName;
                    $dst        = $targetLocation.DS.'large'.DS.$fileName;
                    $cropped = $fObj->resizeThumbnailImage($dst, $src, $this->_request['w'] , $this->_request['h'],$this->_request['x'], $this->_request['y'], 1);
                }
            }   
        }
        
		return $actMsg;
    }
    
    function createMedia($targetLocation) {
        $indexingSource = MEDIA_FILES_ROOT.DS.'index.php';
        @mkdir($targetLocation, 0755); 
        copy($indexingSource, $targetLocation.DS.'index.php');

        @mkdir($targetLocation.DS.'large',      0755); 
        copy($indexingSource, $targetLocation.DS.'large'.DS.'index.php');

        @mkdir($targetLocation.DS.'normal',     0755); 
        copy($indexingSource, $targetLocation.DS.'normal'.DS.'index.php');

        @mkdir($targetLocation.DS.'small',      0755);   
        copy($indexingSource, $targetLocation.DS.'small'.DS.'index.php');

        @mkdir($targetLocation.DS.'thumb',      0755); 
        copy($indexingSource, $targetLocation.DS.'thumb'.DS.'index.php');
    }
    
    function multiAction() {
        $actMsg['type']           = 0;
        $actMsg['message']        = '';
        
        if($this->_request['multiAction']){
            foreach($this->_request['selectMulti'] as $val) {
                
                $params = array();  
                
                switch($this->_request['multiAction']) {
                    case "1":
                        $params['status']       = 'Y';
                        break;
                    case "2":
                        $params['status']       = 'N';
                        break;
                    case "3":
                        $params['delete']       = 'Y';
                        break;
                    case "4":
                        $params['isShowcase']   = 'Y';
                        break;
                    case "5":
                        $params['isShowcase']   = 'N';
                        break;
                    default:
                        $this->response('', 406);
                } 
                
                if($params['delete'] == 'Y') {
                    $gallery = $this->model->galleryById($val);
                    
                    if($gallery){
                        if($gallery['galleryImage'] && file_exists(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$gallery['galleryImage'])){
                            @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$gallery['galleryImage']);
                            @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/normal/'.$gallery['galleryImage']);
                            @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/large/'.$gallery['galleryImage']);
                        }
                        
                        $this->model->deleteGallery($val);
                    }
                }
                else
                    $this->model->galleryUpdateById($params, $val);
                
                $actMsg['type']           = 1;
                $actMsg['message']        = 'Operation successful.';
            }
        }
        
        return $actMsg;
    }

    function deleteFile(){
        $actMsg['type']           = 0;
        $actMsg['message']        = '';

        if($this->_request['DeleteFile'] == 'galleryImage'){
            $selData = $this->model->galleryById($this->_request['IdToEdit']);
            if($selData['galleryImage']){
                @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/normal/'.$selData['galleryImage']);
                @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$selData['galleryImage']);
                @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/large/'.$selData['galleryImage']);

                // update image field to blank
                $params                     = array();
                $params['galleryImage']    = '';
                $this->model->galleryUpdateById($params, $this->_request['IdToEdit']);
            }

            $actMsg['type']           = 1;
            $actMsg['message']        = 'Banner deleted successfully.';
        }

        return $actMsg;  
    }
    
    function deleteImg(){
        $actMsg['type']           = 0;
        $actMsg['message']        = '';
        
        if($this->_request['DeleteImg']){
            $selData = $this->model->galleryGalleryById($this->_request['DeleteImg']);
            
            if($selData['galleryImage']) {
                @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/normal/'.$selData['galleryImage']);
                @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$selData['galleryImage']);
                @unlink(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/large/'.$selData['galleryImage']);
                
                // delete image
                $this->model->deleteGalleryGallery($this->_request['DeleteImg']);
            }
            
            $actMsg['type']           = 1;
            $actMsg['message']        = 'Image deleted successfully.';
        }
        else{
            $actMsg['message']        = 'Something went wrong. Please close your browser window and try again.';
        }
        return $actMsg;  
    }
    
    function swap() {
        $actMsg['type']             = 0;
        $actMsg['message']          = '';
        
        $listingCounter = 1;
        
        foreach ($this->_request['recordsArray'] as $recordID) {
            $params = array();
            $params['displayOrder'] = $listingCounter;
            $this->model->galleryUpdateById($params, $recordID);
            $listingCounter = $listingCounter + 1;
        }
        
        if($listingCounter > 1){
            $actMsg['type']             = 1;
            $actMsg['message']          = 'Operation successful.';
        }
        
        return $actMsg;
    }
    
    function modPage(){
        $srch = trim($this->_request['srch']);
        if($srch) {
            return $this->model->searchLinkedPages($this->_request['mid'], $this->_request['pageType'], $srch, 0, 10);
        }
    }
    
    function setDefaultAlbum() {
        $params                 = array();
        $params['galleryName']  = '';
        $params['permalink']    = 'none';
        $params['entryDate']    = date('Y-m-d H:i:s');
        $params['groupDate']    = date('Y-m-d H:i:s');
        $params['galleryDate']  = date('Y-m-d H:i:s');
        $params['id']           = $this->model->newGallery($params);
        
        $record[] = $params;
        
        return $record;
    }
}