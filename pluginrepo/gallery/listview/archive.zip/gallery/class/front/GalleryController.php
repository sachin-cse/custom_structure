<?php defined('BASE') OR exit('No direct script access allowed.');
class GalleryController extends REST
{
    private    $model;
	protected  $pageview;
	protected  $response = array();
	private    $settings = array();
	
    public function __construct($model) {
    	parent::__construct();
        $this->model        = new $model;
    }
    
	function index($pageData = []) {
        
        if($this->_request['dtls'])
            return;
		
        if($pageData) {
            
            $this->pageData     = $pageData;
            
            $settings           = $this->model->settings($pageData['parent_dir']);
            $settings           = unserialize($settings['value']);
            $settings['name']   = $pageData['parent_dir'];
            $this->settings     = $settings;
            
            $this->response['pageContent']  = $this->content($pageData['categoryId']);

            if($settings['isAlbum']){
                $ExtraQryStr                = 1;
                $albums                     = $this->model->getAlbumByLimit($ExtraQryStr, 0, 100);

                $slider                     = ($settings['albumPosition'] == 'Top' || $settings['albumPosition'] == 'Bottom') ? true : false;
                $albumList                  = $this->albumList($albums, 'col-sm-12', $slider);
                $this->response['albumList']= implode($albumList);
                $this->response['albumPosition'] = $settings['albumPosition'];

                if($this->_request['dtaction']){
                    $album                  = $this->model->galleryByPermalink($this->_request['pageType']);
                    $ExtraQryStr            = 'parentId = '.$album['id'];
                }
                else
                    $ExtraQryStr            = 1;
            }
            elseif($this->_request['dtaction'])
                return;
            else
                $ExtraQryStr                = 1;

            $records                        = $this->gallery($ExtraQryStr);

            $itemList                       = ($records)? $this->itemList($records):'';
            $this->response['itemList']     = implode($itemList);

            $this->pageview                 = 'index.php';
            
            if($this->pageview) {

                $this->response['body']     = $this->pageview;
                $this->response['pageData'] = $pageData;
                return $this->response; 
            }
        }
    }
    
    function gallery($ExtraQryStr) {
        
		$this->response['rowCount']			 = $this->model->galleryCount($ExtraQryStr);
		
		if($this->response['rowCount']) {
                
			$p                               = new Pager;
			$this->response['limit']         = ($this->settings['limit'])? $this->settings['limit'] : VALUE_PER_PAGE;
			$start                           = $p->findStart($this->response['limit'], $this->_request['page']);
			$pages                           = $p->findPages($this->response['rowCount'], $this->response['limit']);

			$records   	                     = $this->model->getGalleryByLimit($ExtraQryStr, $start, $this->response['limit']);

			if(ceil($this->response['rowCount'] / $this->response['limit']) > 1) {
				$this->response['page']      = ($this->_request['page']) ? $this->_request['page'] : 1;
				$this->response['totalPage'] = ceil($this->response['rowCount'] / $this->response['limit']);

				$this->response['pageList']  = $p->pageList($this->response['page'], $_SERVER['REQUEST_URI'], $pages);
            }
            
            return $records;
		}
    }
    
    function content($categoryId) {
            
        $rsArry 				            = [];

        $rsArry['contentCount']	            = $this->model->countContentbymenucategoryId($categoryId);

        if($rsArry['contentCount']) {

            $p                              = new Pager;
            $rsArry['contentLimit']         = VALUE_PER_PAGE;
            $start                          = $p->findStart($rsArry['contentLimit'], $this->_request['contentPage']);
            $contentPages                   = $p->findPages($rsArry['contentCount'], $rsArry['contentLimit']);

            $rsArry['content']              = $this->model->getContentbymenucategoryId($categoryId, $start, $rsArry['contentLimit']);

            if($rsArry['contentCount'] > 0 && ceil($rsArry['contentCount'] / $rsArry['contentLimit']) > 1) {
                
                $rsArry['contentPage']      = ($this->_request['contentPage']) ? $this->_request['contentPage'] : 1;
                $rsArry['totalContentPage'] = ceil($rsArry['contentCount'] / $rsArry['contentLimit']);

                $rsArry['contentPageList']  = $p->pageList($rsArry['contentPage'], $_SERVER['REQUEST_URI'], $contentPages);
            }
    	    return $rsArry;
        }
    }
	    
    function ajx_action($pageData = []){
        
    }
    
    function showcase($opt = []) {
        
        $settings           = $this->model->settings($opt['module']);
        $settings           = unserialize($settings['value']);
        $settings['name']   = $opt['module'];
        $this->settings     = $settings;
        
        if($settings['isShowcase']) {
        
            $showcaseFile           = CACHE_ROOT.DS.'gallery_showcase.html';
            if(file_exists($showcaseFile)) {
                include $showcaseFile;
                return;
            }

            $limit      = ($settings['showcaseNo'])? $settings['showcaseNo'] : 3;
            $records	= $this->model->getGalleryByLimit("isShowcase = 'Y'", 0, $limit);

            if($records) {

                $wrapcss    = ($opt['wrapcss']) ?   $opt['wrapcss'] : '';
                $css        = ($opt['css']) ?       $opt['css']     : '';
                $col        = ($opt['col'])?        $opt['col']     : 'col-sm-4 col-xs-6';
                $slider     = ($opt['slider'])?     $opt['slider']  : false;
                $withIcon   = ($settings['isIcon'])?'withIcon'      : '';

                $this->result[]   = '<section class="section '.$wrapcss.'">
                                        <div class="container">
                                            <h2 class="heading">'.headingModify($settings['showcaseTitle']).'</h2>';

                if(trim($settings['showcaseDescription'])) {
                    $this->result[]   = '<div class="sk_content_wrap mb30">
                                        <div class="sk_content">
                                            <div class="editor_text">
                                                '.$settings['showcaseDescription'].'
                                            </div>
                                        </div>
                                    </div>';
                }

                $this->result[]   = '<div class="'.$css.'">';
                
                $this->itemList($records, $col, $slider);
                
                $this->result[] = '</div>';
                
                $pageData           = $this->model->pageBymodule($opt['module']);
                
                $this->result[] = '<div class="btn_group btn_center"><a class="btn" href="'.SITE_LOC_PATH.'/'.$pageData['permalink'].'/">View All</a></div>';
                $this->result[] = '</div></section>';

                $html = implode($this->result);

                echo $html;
            }
        }
    }
    
    function albumList($albums, $col = 'col-sm-12', $slider = false) {
        
        if($slider === true){
            $this->album[]      = '<div class="owl-carousel">';
            $itemElem           = '<div class="item">';
            $itemElemEnd        = '</div>';
            $itemElemWrapEnd    = '</div>';
        } else {
            $this->album[]      = '<ul class="ul row">';
            $itemElem           = '<li class="'.$col.'">';
            $itemElemEnd        = '</li>';
            $itemElemWrapEnd    = '</ul>';
        }

        $this->album[]          = $itemElem.'<a href="'.(($this->_request['dtaction']) ? SITE_LOC_PATH.'/'.$this->_request['dtaction'].'/' : SITE_LOC_PATH.'/'.$this->_request['pageType'].'/').'" class="sk_album '.((!$this->_request['dtaction']) ? 'selected' : '').'">All Photos</a>'.$itemElemEnd;
        
        foreach($albums as $data) {
            
            $link       = SITE_LOC_PATH.'/'.$data['permalink'].'/'.(($this->_request['dtaction']) ? $this->_request['dtaction'] : $this->_request['pageType']).'/';
            $active     = ($this->_request['pageType'] == $data['permalink']) ? 'selected' : '';
            $albumName  = ($data['galleryName']) ? $data['galleryName'] : 'Photos';

            if($data['galleryName'] != '') {
                $this->album[] = sprintf('%s
                            <a href="%s" class="sk_album %s">%s</a>
                        %s', $itemElem, $link, $active, $data['galleryName'], $itemElemEnd);
            }
        }
        $this->album[]   = $itemElemWrapEnd;
        
        if($slider === true){
            $this->album[]   = "<script defer type='text/javascript'>
                                function owlAlbum(){
                                if(window.jQuery){
                                    $('.album_list .owl-carousel').owlCarousel({
                                        items: 5,
                                        loop: false,
                                        autoplay: false,
                                        autoplayTimeout: 3000,
                                        margin: 30,
                                        dots: false,
                                        nav: true,
                                        navElement: 'div',
                                        navText: [\"<i class='fa fa-angle-left'></i>\", \"<i class='fa fa-angle-right'></i>\"],
                                        autoWidth: true,
                                        responsive: {
                                            0: { items: 2 },
                                            480: { items: 2 },
                                            600: { items: 3 },
                                            768: { items: 4 },
                                            992: { items: 5 },
                                            1600: { items: 5 }
                                        }, 
                                    });} else {setTimeout(function(){ owlAlbum();}, 50);}}owlAlbum();</script>";
        }

        return $this->album;
    }
    
    function itemList($records, $col = 'col-sm-12', $slider = false) {
        
        if($slider === true){
            $this->result[]     = '<div class="owl-carousel">';
            $itemElem           = '<div class="item">'; 
            $itemElemEnd        = '</div>'; 
            $itemElemWrapEnd    = '</div>'; 
            $lazyClass          = 'owl-lazy';
        } else {
            $this->result[]     = '<ul class="ul row">';
            $itemElem           = '<li class="'.$col.'">';
            $itemElemEnd        = '</li>'; 
            $itemElemWrapEnd    = '</ul>'; 
            $lazyClass          = 'lazy';
        }
        
        foreach($records as $data) {

            $figureImg = '';

            if( $this->settings['isGallery'] ) {

                if( $data['galleryImage'] && file_exists(MEDIA_FILES_ROOT.DS.$this->settings['name'].DS.'thumb'.DS.$data['galleryImage']) ){
                    $figThumb = MEDIA_FILES_SRC.'/'.$this->settings['name'].'/thumb/'.$data['galleryImage'];
                    $figNormal = MEDIA_FILES_SRC.'/'.$this->settings['name'].'/normal/'.$data['galleryImage'];
                }

                if($figThumb) {

                    $figureImg = '<figure>
                                <img class="'.$lazyClass.'" src="'.STYLE_FILES_SRC.'/images/blank.png" data-src="'.$figThumb.'" alt="'.$data['galleryName'].'">
                            </figure>';
                }
            }

            $desp = '<h2>'.$data['galleryName'].'</h2>'.$data['galleryDescription'];

            if($figureImg) {
                $this->result[] = sprintf('%s
                            <div class="sk_box">
                                <a href="%s" data-lcl-thumb="%s" data-lcl-txt="%s" class="sk_gal">%s
                                    <div class="sk_text">
                                        <span class="readmore">View</span>
                                        <h2 class="subheading">%s</h2>
                                    </div>
                                </a>
                            </div>
                        %s', $itemElem, $figNormal, $figThumb, $desp, $figureImg, $data['galleryName'], $itemElemEnd);
            }
        }
        $this->result[]   = $itemElemWrapEnd;
        
        $this->result[]   = "<script defer type='text/javascript'>
                            function lightbox(){
                            if(window.jQuery){
                                lc_lightbox('.sk_gal', {
                                    wrap_class: 'lcl_fade_oc',
                                    gallery : true,
                                    thumb_attr: 'data-lcl-thumb',
                                    skin: 'dark',
                                    radius: 0,
                                    padding	: 0,
                                    border_w: 0,
                                    shadow: true,
                                    autoplay: false,
                                    counter: true,
                                    ol_opacity: 0.8,
                                    ol_color: '#000',
                                    cmd_position: 'outer',
                                    data_position: 'under', 
                                    ins_close_pos: 'corner', 
                                    nav_btn_pos: 'middle', 
                                    txt_hidden: 767,
                                    thumbs_w: 90,
                                    thumbs_h: 90,
                                    modal: false,
                                    rclick_prevent: false,
                                });} else {setTimeout(function(){ lightbox();}, 50);}}lightbox();</script>";

        return $this->result;
    }
}