<?php defined('BASE') OR exit('No direct script access allowed.');
class GalleryModel extends ContentModel
{
	function getAlbumByLimit($ExtraQryStr, $start, $limit) {
		$ExtraQryStr .= " AND parentId = 0 AND id <> 1 AND status = 'Y' ORDER BY groupDate";
		return $this->selectMulti(TBL_GALLERY, "*", $ExtraQryStr, $start, $limit); 	
	}

    function galleryById($id) {
		$ExtraQryStr = "id = ".addslashes($id);
		return $this->selectSingle(TBL_GALLERY, "*", $ExtraQryStr);
	}
	
    function galleryByPermalink($permalink) {
		$ExtraQryStr = "permalink = '".addslashes($permalink)."'";
		return $this->selectSingle(TBL_GALLERY, "*", $ExtraQryStr);
	}
    
    function galleryCount($ExtraQryStr) {
		$ExtraQryStr .= " AND parentId <> 0 AND status = 'Y'";
        return $this->rowCount(TBL_GALLERY, "id", $ExtraQryStr);
	}
    
    function getGalleryByLimit($ExtraQryStr, $start, $limit) {
		$ExtraQryStr .= " AND parentId <> 0 AND status = 'Y' ORDER BY displayOrder";
		return $this->selectMulti(TBL_GALLERY, "*", $ExtraQryStr, $start, $limit); 	
	}
    
    function getGalleryList($ExtraQryStr) {
		$ExtraQryStr .= " AND status = 'Y' ORDER BY displayOrder";
		return $this->selectAll(TBL_GALLERY, "galleryName, permalink", $ExtraQryStr); 	
	}
	
	/* ----------------------------------------- TBL_SETTINGS ------------------------------------------------ */
	function settings($name) {
        $ExtraQryStr = "name = '".addslashes($name)."'";
		$settings = $this->selectSingle(TBL_SETTINGS, "value", $ExtraQryStr);
        
        return $settings;
    }
    
    function pageBymodule($parent_dir){
        $ENTITY         =  TBL_MENU_CATEGORY." mc JOIN ".TBL_MODULE." m ON (m.menu_id = mc.moduleId)";
        $ExtraQryStr    = "m.parent_dir = '".addslashes($parent_dir)."'";
		return $this->selectSingle($ENTITY, "mc.*", $ExtraQryStr);

    }
}