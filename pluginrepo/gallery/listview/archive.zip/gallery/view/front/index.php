<?php
defined('BASE') OR exit('No direct script access allowed');

include('content.php');

if($data['itemList']) {
    if($data['albumList'] && $data['albumPosition'] != 'Bottom') {
        if($data['albumPosition'] == 'Left' || $data['albumPosition'] == 'Right'){
            $albumStart 	= '<div class="row"><div class="col-md-3 col-sm-4 stickySidebar '.(($data['albumPosition'] == 'Right') ? 'pull-right' : '').'"><div class="sk_sideblock sk_sideblockShadow">';
            $albumMiddle	= '</div></div><div class="col-md-9 col-sm-8 stickyContent">';
            $albumEnd 		= '</div></div>';
            $albumTitle		= '<div class="subheading border_btm">Albums</div>';
        }
        else
            $albumStart = $albumMiddle = $albumEnd = $albumTitle = '';

        echo $albumStart.$albumTitle.'<div class="album_list">'.$data['albumList'].'</div>'.$albumMiddle;
    }
    
    echo '<div class="gallery_list masonry">'.$data['itemList'].'</div>';

	if(isset($data['pageList'])) {
		echo '<div class="pagination">';
		echo '<p class="total">Page '.$data['page'].' of '.$data['totalPage'].'</p>';
		echo '<div>'.$data['pageList'].'</div>';
		echo '</div>';
	}	
    
    echo ($data['albumList'] && $data['albumPosition'] == 'Bottom') ? '<div class="album_list">'.$data['albumList'].'</div>' :'';
    
    echo $albumEnd;
}
else
	echo '<div class="norecord">No record found!</div>';
?>