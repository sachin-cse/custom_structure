<?php
defined('BASE') OR exit('No direct script access allowed.');


if($data['linkedPages']) {
    ?>
    <div class="container-fluid">
        <?php
        if($data['act']['message'])
            echo ($data['act']['type'] == 1)? '<div class="alert alert-success">'.$data['act']['message'].'</div>':'<div class="alert alert-danger">'.$data['act']['message'].'</div>';
        ?>

        <div class="row">
            <div class="col-sm-9">
                <div class="card">
                    <div class="card-body">
                        <form name="searchForm" action="" method="post">
                            <div class="form-inline">
                                <div class="form-group">
                                    <input type="text" name="searchText" value="<?php echo $this->session->read('searchText');?>" placeholder="Search" class="form-control">
                                </div>
                                
                                <div class="form-group">
                                    <select name="searchStatus" class="form-control">
                                        <option value="">Status</option>
                                        <option value="Y" <?php if ($this->session->read('searchStatus') == 'Y') echo 'selected';?>>Active</option>
                                        <option value="N" <?php if ($this->session->read('searchStatus') == 'N') echo 'selected';?>>Inactive</option>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <select name="searchShowcase" class="form-control" style="width:110px;">
                                        <option value="">All</option>
                                        <option value="Y" <?php if ($this->session->read('searchShowcase') == 'Y') echo 'selected';?>>Showcase Items</option>
                                    </select>
                                </div>
                                
                                <?php if($data['albums'] && $data['settings']['isAlbum']){?>
                                    <div class="form-group">
                                        <select name="searchAlbum" class="form-control" style="width:95px;">
                                            <option value="">All Albums</option>
                                            <?php
                                            foreach($data['albums'] as $album){
                                                if($album['galleryName'] == '')
                                                    echo '<option value="'.$album['id'].'" '.(($this->session->read('searchAlbum') == $album['id']) ? 'selected' : '').'>None</option>';
                                                else
                                                    echo '<option value="'.$album['id'].'" '.(($this->session->read('searchAlbum') == $album['id']) ? 'selected' : '').'>'.$album['galleryName'].'</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                <?php }?>
                                
                                <div class="form-group">
                                    <button type="submit" name="Search" class="btn btn-info width-auto"><i class="fa fa-search"></i></button>
                                    <button type="submit" name="Reset" class="btn btn-dark width-auto m-l-10"><i class="fa fa-refresh"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="card">
                    <div class="card-body text-center">
                        <a href="#" class="btn btn-info addGallery">Add Photos</a>
                    </div>
                </div>
            </div>
        </div>

        <?php
        $blankLi = '<li class="col-sm-4"><div class="uploadImgBox"><label class="uploadImg"><div class="uploadImgShow" id="dp" style="background-image:url('.ADMIN_TMPL_PATH.'/images/upload_img.jpg);"></div></label><input type="text" name="galleryName[]" placeholder="Caption"><textarea name="galleryDescription[]" placeholder="Description" class="phcaption"></textarea><span class="removePhoto" data-action=""><i class="fa fa-times"></i></span></div><input type="hidden" name="ts[]" value=""></li>';

        $albumWrap = '<div class="form-group"><label>Album Name</label><input type="text" name="albumName" value="" class="form-control"></div><div class="form-group"><label>Description</label><textarea name="albumDescription" class="form-control" style="height:121px;"></textarea></div>';
        ?>
        <div class="row galleryWrap" style="display: none;">
            <div class="col-sm-12">
                <div class="card p-0">
                    <div class="card-body">
                        <div class="uploadImgWrap mb30" style="display: block;">
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div <?php echo ($data['settings']['isAlbum'])? 'class="col-sm-8 contentL" style="border-right:1px solid rgba(0,0,0,.1);"':'class="col-sm-12"'; ?> >
                                        <div class="p-20">
                                            <ul class="galleryImageFile">
                                                <li><input type="file" name="galleryImage[]" multiple class="uploadInput" data-img="dp" accept="image/*"></li>
                                            </ul>
                                            <ul class="uploadul row">
                                                <li class="col-sm-4 uploadli"><div class="uploadImgMore"><i class="fa fa-plus"></i></div></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php if($data['settings']['isAlbum']) {?>
                                    <div class="col-sm-4 contentS">
                                        <div class="p-20">
                                            <div class="form-group">
                                                <label>Select Album</label>
                                                <select name="parentId" class="form-control albumId">
                                                    <?php
                                                    $keyNone = array_search('none', array_column($data['albums'], 'permalink'));
                                                    echo '<option value="'.$data['albums'][$keyNone]['id'].'">None</option>';
                                                    echo '<option value="0">Create Album</option>';

                                                    if(sizeof($data['albums']) > 1) {
                                                        echo '<optgroup label="Albums">';
                                                        foreach($data['albums'] as $album) {
                                                            if($album['galleryName'])
                                                                echo '<option value="'.$album['id'].'">'.$album['galleryName'].'</option>';
                                                        }
                                                        echo '</optgroup>';
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Date</label>
                                                <input type="text" name="albumDate" value="<?php echo date('Y-m-d');?>" class="form-control datepicker" placeholder="YYYY-MM-DD" autocomplete="off">
                                            </div>
                                            <div class="albumWrap disable">
                                                <div class="form-group">
                                                    <label>Album Name</label>
                                                    <input type="text" name="albumName" value="" class="form-control">
                                                </div>
                                                <div class="form-group">
                                                    <label>Description</label>
                                                    <textarea name="albumDescription" class="form-control" style="height:121px;"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php }?>
                                </div>
                                <hr class="m-t-0">
                                <div class="p-20 p-t-0">
                                    <input type="hidden" name="SourceForm" value="uploadPhotos">
                                    <input type="hidden" name="filesArray">
                                    <button type="submit" name="Save" class="btn btn-info">Upload</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            
        <div>
            <form action="" method="post">
                <div class="row">
                
                    <div class="col-sm-12">
                        <div class="card">
                            <?php
                            if($data['records']) {
                                
                                if(sizeof($data['records']) == 1 && $data['records'][0]['permalink'] == 'none')
                                    echo 'No records found!';
                                else {
                                
                                    $slNo = ($this->_request['page'] > 1) ? (($this->_request['page'] - 1) * $data['limit']) + 1 : 1;
                                    foreach($data['records'] as $key=>$record) {
                                        $conStatus  = ($record['status'] == 'Y') ? 'active' : 'inactive';

                                        if($record['parentId'] == 0) {
                                            $parentId = $record['id'];
                                            
                                            echo '<div class="card-wrap">';
                                            
                                            
                                            echo  '<div class="card-title">
                                                    <h4 class="grpselect">
                                                        <label class="sliderCheck"><input class="selectall" name="selectMulti[]" type="checkbox" value="'.$record['id'].'"><span></span></label>'.(($record['galleryName'] != '' && $data['settings']['isAlbum']) ? '<span class="m-r-30" style="font-weight:bold">'.$record['galleryName'].'</span>' : '').'<span style="color:#898989;font-size:16px">'.strtoupper(date('j M, Y',strtotime($record['galleryDate']))).'</span>
                                                    </h4>
                                                </div>';
                                            
                                            echo '<div class="card-body">';
                                            echo '<hr class="m-t-0 m-b-20">';
                                            echo '<ul class="row swap">';
                                        }
                                        else {
                                            ?>
                                            <li class="col-sm-3" id="<?php echo 'recordsArray_'.$record['id'];?>">
                                                <div class="card p-0 <?php echo $conStatus;?>">
                                                    <div class="card-body">
                                                        <div class="sliderBox gallerySliderBox">
                                                            <label class="sliderCheck"><input type="checkbox" name="selectMulti[]" value="<?php echo $record['id'];?>" class="case" /><span></span></label>
                                                            <a href="index.php?pageType=<?php echo $this->_request['pageType'];?>&dtls=<?php echo $this->_request['dtls'];?>&dtaction=add&editid=<?php echo $record['id'];?>&moduleId=<?php echo $this->_request['moduleId'];?>">
                                                                <div class="sliderImg">
                                                                    <?php
                                                                    if($data['settings']['isGallery'] && $record['galleryImage'] && file_exists(MEDIA_FILES_ROOT.'/'.$this->_request['pageType'].'/thumb/'.$record['galleryImage']))
                                                                        echo '<img src="'.MEDIA_FILES_SRC.'/'.$this->_request['pageType'].'/thumb/'.$record['galleryImage'].'?t='.time().'" alt="'.$record['galleryName'].'">';
                                                                    ?>
                                                                </div>
                                                                <?php

                                                                echo ($record['galleryName']) ? '<div class="sliderText">'.$record['galleryName'].'</div>' : '';?>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <?php
                                        }
                                        if(($data['records'][$key+1]['parentId'] != $parentId) || $key == sizeof($data['records']) - 1) {
                                            echo '</ul>
                                            </div>
                                            </div>';
                                        }

                                        $slNo++;
                                    }
                                    
                                }
                            }
                            else
                                echo '<div class="card-body"><div class="norecord text-center">No Record Present</div></div>';
                            ?>
                        </div>
                                
                        <?php
                        if($data['records']) { ?>
                            <div class="card m-t-20">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-5 pull-right">
                                            <div class="last_li form-inline">
                                                <select name="multiAction" class="form-control multi_action">
                                                    <option value="">Select</option>
                                                    <option value="1">Active</option>
                                                    <option value="2">Inactive</option>
                                                    <option value="3">Delete</option>
                                                    <option value="4">Add to Showcase</option>
                                                    <option value="5">Remove from Showcase</option>
                                                </select>
                                                <input type="hidden" name="SourceForm" value="multiAction">
                                                <button type="submit" name="Save" value="Apply" class="btn btn-info m-l-10">Apply</button>
                                            </div>
                                        </div>
                                        <?php
                                        if($data['pageList']){
                                            echo '<div class="col-sm-7">';
                                            echo '<div class="pagination">';
                                            echo '<p class="total">Page '.$data['page'].' of '.$data['totalPage'].'</p>';
                                            echo '<div>'.$data['pageList'].'</div>';
                                            echo '</div>';
                                            echo '</div>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        <?php }?>
                    </div>
                    
                </div>
            </form>
        </div>
    </div>

    <script>
        $(function () {

            $(document).on('click', '.addGallery', function (e) {
                e.preventDefault;
                $('.galleryWrap').slideToggle();
            });

            /* $(document).on('fileselect', ':file', function (event, numFiles, label) {
                var input = $(this).parents('.file_upload').find(':text'),
                    log = numFiles > 1 ? numFiles + ' files selected' : label;

                if (input.length) {
                    input.val(log);
                } else {
                    if (log) alert(log);
                }
            }); */

            /* $(document).on('change', ':file', function () {
                var input = $(this),
                    numFiles = input.get(0).files ? input.get(0).files.length : 1,
                    label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
                input.trigger('fileselect', [numFiles, label]);

                if ($('.showpic').length) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('.showpic').css({
                            'background-image': 'url(' + e.target.result + ')'
                        }).fadeIn();
                    }
                    reader.readAsDataURL(this.files[0]);
                }
            }); */

            var blankLi = '<?php echo $blankLi;?>';

            $(document).on('change', ':file', function () {
                var elem = $(this), 
                    ul = elem.parents('ul').next('ul'),
                    numFiles = elem.get(0).files ? elem.get(0).files.length : 1,
                    elemVal = elem.val(),
                    label = elem.val().replace(/\\/g, '/').replace(/.*\//, '');

                var ts = '';
                
                for(var i=0; i<numFiles; i++) {
                    var reader = new FileReader();
                    var fileName = this.files[i];
                    
                    
                    reader.onload = (function(theFile){
                        var fileName = theFile.name;
                        
                        
                        return function(e) {
                            ul.prepend(blankLi);
                            ul.children('li:first-child').find('[name="ts[]"]').val(fileName);
                            ul.children('li:first-child').find('.uploadInput').remove();
                            ul.children('li:first-child').find('.uploadImgShow').attr('style', 'background-image:url('+e.target.result+')');
                        };
                    })(fileName);   
                    //reader.readAsText(fileName);
                    
                    reader.readAsDataURL(this.files[i]);
                }

                $('.galleryImageFile').prepend('<li><input type="file" name="galleryImage[]" multiple class="uploadInput" data-img="dp" accept="image/*"></li>');
              
            });

            $(document).on('click', '.uploadMyImgBtn', function (e) {
                e.preventDefault;
                $(this).siblings('.uploadImgWrap').slideToggle();
            });

            $(document).on('change', '.albumId', function () {
                var val = $(this).val(),
                    noneId = '<?php echo $data['albums'][$keyNone]['id'];?>';
                if(val == 0){
                    $('.albumWrap').removeClass('disable');
                    $('[name="albumDate"]').val("<?php echo date('Y-m-d');?>");
                    $('.albumWrap').find('[name="albumName"]').val('');
                    $('.albumWrap').find('[name="albumDescription"]').val('');
                }
                else if(val == noneId){
                    $('.albumWrap').addClass('disable');
                    $('[name="albumDate"]').val("<?php echo date('Y-m-d');?>");
                    $('.albumWrap').find('[name="albumName"]').val('');
                    $('.albumWrap').find('[name="albumDescription"]').val('');
                }
                else {
                    $('.albumWrap').removeClass('disable');

                    $.ajax({
                        type	: 'POST',
                        url		: "./index.php?pageType=<?php echo $this->_request['pageType'];?>&dtls=<?php echo $this->_request['dtls'];?>",
                        data	: {'ajx_action': 'getAlbum', 'id': val},
                        success	: function (response) {
                            
                            if (response.type == 1) {
                                $('[name="albumDate"]').val(response.albumDate);
                                $('.albumWrap').find('[name="albumName"]').val(response.albumName);
                                $('.albumWrap').find('[name="albumDescription"]').html(response.albumDescription);
                            }
                        }
                    });
                }
            });

            $(document).on('click', '.uploadImgMore', function (e) {
                e.preventDefault;
                var newLi = blankLi;
                
                if($(this).parents('.uploadImgWrap ul').children('li').length >= 21)
                    sAlert('warning', 'You can not uploaded more than 20 images at a time.', false);
                else
                    $('.galleryImageFile').children('li:first-child').find('.uploadInput:file').trigger('click');
            });

            $(document).on('click', '.removePhoto', function (e) {
                e.preventDefault;
                var ul      = $(this).parents('.uploadImgWrap ul'),
                    action  = $(this).attr('data-action'),
                    ts      = $(this).parents('li').find('[name="ts[]"]').val();

                if(action == 'confirm'){
                    var photoId = $(this).attr('data-id');
                    /* misteryMessageConfirm('Are you sure?', 'confirm', photoId, 'deletePhoto'); */
                    swal({
                        title: "Are you sure?",
                        text: "",
                        type: "confirm",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Yes, delete it !!",
                        closeOnConfirm: false
                    },
                    function(){
                        swal("Deleted!", "Hey, your imaginary file has been deleted!", "success");
                    });
                }
                else{
                    $(this).parents('li').remove();

                    if(ul.children('li').length <= 1)
                        ul.html(blankLi);
                }



                console.log($('[name="ts[]"]').val());
            });

        });
    </script>
    <?php
}
else{
    echo '<div class="container-fluid">
        <div class="norecord alert alert-warning text-center p-t-30 p-b-35">
            <div class="m-b-20">There is no page linked with this module.</div>
            <a href="'.SITE_ADMIN_PATH.'/index.php?pageType=sitepage&dtls=pages&dtaction=new&moduleId=100" class="btn btn-info btn-sm m-r-10">Add Page</a> or
            <a href="'.SITE_ADMIN_PATH.'/index.php?pageType=sitepage&dtls=pages&moduleId=101" class="btn btn-info btn-sm m-l-10">View Pages</a>
        </div>
    </div>';
}
?>